Generated settings live here (data/settings.json). Safe to delete - it rebuilds from defaults.
