/* Small helpers shared by every page. */

(function (global) {
  'use strict';

  var currency = '\u20b9';

  function setCurrency(symbol) { if (symbol) currency = symbol; }

  function esc(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function num(value, digits) {
    if (value === null || value === undefined || isNaN(value)) return '-';
    var d = digits === undefined ? 1 : digits;
    return Number(value).toLocaleString(undefined, {
      minimumFractionDigits: d, maximumFractionDigits: d
    });
  }

  function money(value, digits) {
    if (value === null || value === undefined || isNaN(value)) return '-';
    return currency + Number(value).toLocaleString(undefined, {
      minimumFractionDigits: digits || 0, maximumFractionDigits: digits || 0
    });
  }

  function dayLabel(iso) {
    var d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  }

  function fullDate(iso) {
    var d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString(undefined, {
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
    });
  }

  function dateOnly(iso) {
    return new Date(iso + 'T00:00:00').toLocaleDateString(undefined, {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  }

  function hourLabel(hour) {
    var h = ((hour % 24) + 24) % 24;
    var suffix = h < 12 ? 'AM' : 'PM';
    return (h % 12 || 12) + ' ' + suffix;
  }

  function timeAgo(iso) {
    var then = new Date(iso);
    var mins = Math.round((Date.now() - then.getTime()) / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' min ago';
    var hrs = Math.round(mins / 60);
    if (hrs < 24) return hrs + ' h ago';
    return Math.round(hrs / 24) + ' d ago';
  }

  function delta(percent) {
    if (percent === null || percent === undefined) return '';
    var dir = percent > 0 ? 'up' : 'down';
    var arrow = percent > 0 ? '\u25b2' : '\u25bc';
    return '<span class="delta ' + dir + '">' + arrow + ' ' + Math.abs(percent).toFixed(1) + '%</span>';
  }

  function tile(options) {
    return '<div class="tile ' + (options.accent || '') + '">' +
      '<span class="label">' + esc(options.label) + '</span>' +
      '<span class="value">' + options.value +
        (options.unit ? '<small>' + esc(options.unit) + '</small>' : '') + '</span>' +
      (options.foot ? '<span class="foot">' + options.foot + '</span>' : '') +
      '</div>';
  }

  function severityBadge(severity) {
    var map = {
      critical: ['crit', 'Critical'], high: ['crit', 'High'],
      warning: ['warn', 'Warning'], medium: ['warn', 'Medium'],
      info: ['info', 'Info'], low: ['info', 'Low']
    };
    var entry = map[severity] || ['info', severity];
    return '<span class="badge ' + entry[0] + '">' + esc(entry[1]) + '</span>';
  }

  function statusBadge(status) {
    var map = {
      'Very high': 'crit', 'High usage': 'crit', 'High': 'warn', 'Watch': 'warn',
      'Normal': '', 'Low': 'ok', 'Efficient': 'ok'
    };
    return '<span class="badge ' + (map[status] || '') + '">' + esc(status) + '</span>';
  }

  function chartBox(id, height) {
    return '<div class="chart" id="' + id + '" style="min-height:' + (height || 260) + 'px"></div>';
  }

  function segmented(name, options, active) {
    return '<div class="seg" role="group" data-seg="' + name + '">' + options.map(function (opt) {
      return '<button type="button" data-value="' + esc(opt.value) + '" aria-pressed="' +
        (opt.value === active) + '">' + esc(opt.label) + '</button>';
    }).join('') + '</div>';
  }

  function toast(message) {
    var node = document.getElementById('toast');
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(node._timer);
    node._timer = setTimeout(function () { node.classList.remove('show'); }, 2600);
  }

  function table(columns, rows) {
    return '<div class="table-wrap"><table><thead><tr>' +
      columns.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      (rows.length ? rows.map(function (r) {
        return '<tr>' + r.map(function (cell) { return '<td>' + cell + '</td>'; }).join('') + '</tr>';
      }).join('') : '<tr><td colspan="' + columns.length + '" class="empty">Nothing to show yet.</td></tr>') +
      '</tbody></table></div>';
  }

  global.UI = {
    esc: esc, num: num, money: money, dayLabel: dayLabel, fullDate: fullDate, dateOnly: dateOnly,
    hourLabel: hourLabel, timeAgo: timeAgo, delta: delta, tile: tile,
    severityBadge: severityBadge, statusBadge: statusBadge, chartBox: chartBox,
    segmented: segmented, toast: toast, table: table, setCurrency: setCurrency,
    currency: function () { return currency; }
  };
})(window);
