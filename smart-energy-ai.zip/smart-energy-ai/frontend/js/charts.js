/* Smart Energy AI - charting.
   Plain SVG built by hand so the app has zero third-party dependencies and works
   with no internet connection. Every chart re-renders on container resize. */

(function (global) {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var COLORS = {
    amber: '#e8871e', teal: '#0f766e', ink: '#10242e', indigo: '#3f5f8f',
    red: '#c0392b', line: '#d3dddd', muted: '#6b8592', soft: '#f0f4f4'
  };

  function el(name, attrs, text) {
    var node = document.createElementNS(NS, name);
    for (var key in attrs) {
      if (attrs[key] !== null && attrs[key] !== undefined) node.setAttribute(key, attrs[key]);
    }
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function niceTicks(max, count) {
    if (!isFinite(max) || max <= 0) return [0, 1];
    var raw = max / count;
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var norm = raw / mag;
    var step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10) * mag;
    var ticks = [];
    for (var v = 0; v <= max + step * 0.5; v += step) ticks.push(Math.round(v * 1000) / 1000);
    return ticks;
  }

  function fmt(value) {
    if (value === null || value === undefined || isNaN(value)) return '-';
    var abs = Math.abs(value);
    if (abs >= 1000) return value.toFixed(0);
    if (abs >= 100) return value.toFixed(0);
    if (abs >= 10) return value.toFixed(1);
    return value.toFixed(2);
  }

  function ensureTip(container) {
    var tip = container.querySelector('.chart-tip');
    if (!tip) {
      tip = document.createElement('div');
      tip.className = 'chart-tip';
      container.appendChild(tip);
    }
    return tip;
  }

  // ---------------------------------------------------------------- cartesian

  function drawCartesian(container, spec, width) {
    var height = spec.height || 260;
    var pad = { t: 14, r: 18, b: spec.rotate ? 62 : 26, l: spec.rotate ? 58 : 46 };
    var series = spec.series || [];
    var labels = spec.labels || [];
    var n = labels.length;

    var maxima = [];
    series.forEach(function (s) {
      (s.values || []).forEach(function (v) { if (v !== null) maxima.push(v); });
      (s.band || []).forEach(function (b) { if (b && b.high !== null) maxima.push(b.high); });
    });
    var max = Math.max.apply(null, maxima.concat([0.001]));
    var ticks = niceTicks(max * 1.08, 5);
    var top = ticks[ticks.length - 1] || 1;

    var plotW = Math.max(width - pad.l - pad.r, 40);
    var plotH = Math.max(height - pad.t - pad.b, 40);

    var gridColor = spec.dark ? '#28464f' : COLORS.line;
    var textColor = spec.dark ? '#8fb0b0' : COLORS.muted;
    var axisColor = spec.dark ? '#3a5b65' : '#b6c5c5';

    var svg = el('svg', {
      viewBox: '0 0 ' + width + ' ' + height, width: width, height: height,
      role: 'img', 'aria-label': spec.ariaLabel || spec.title || 'chart'
    });

    function x(i) { return n <= 1 ? pad.l + plotW / 2 : pad.l + (plotW * i) / (n - 1); }
    function xBand(i) { return pad.l + (plotW * (i + 0.5)) / Math.max(n, 1); }
    function y(v) { return pad.t + plotH - (Math.max(v, 0) / top) * plotH; }

    // gridlines + y axis
    ticks.forEach(function (t) {
      svg.appendChild(el('line', {
        x1: pad.l, x2: pad.l + plotW, y1: y(t), y2: y(t),
        stroke: gridColor, 'stroke-width': 1
      }));
      svg.appendChild(el('text', {
        x: pad.l - 8, y: y(t) + 4, 'text-anchor': 'end',
        'font-size': 11, fill: textColor
      }, fmt(t)));
    });

    // highlighted x band (e.g. peak hours)
    if (spec.highlight) {
      var useBand = spec.type === 'bar';
      var hx1 = useBand ? xBand(spec.highlight.from) - plotW / n / 2 : x(spec.highlight.from);
      var hx2 = useBand ? xBand(spec.highlight.to) + plotW / n / 2 : x(spec.highlight.to);
      svg.insertBefore(el('rect', {
        x: hx1, y: pad.t, width: Math.max(hx2 - hx1, 2), height: plotH,
        fill: spec.highlight.color || '#fbead6', opacity: 0.75
      }), svg.firstChild);
      if (spec.highlight.label) {
        svg.appendChild(el('text', {
          x: (hx1 + hx2) / 2, y: pad.t + 12, 'text-anchor': 'middle',
          'font-size': 10.5, fill: spec.dark ? '#e0a96b' : '#8a4f06'
        }, spec.highlight.label));
      }
    }

    // target line
    if (spec.target !== undefined && spec.target !== null && spec.target <= top) {
      svg.appendChild(el('line', {
        x1: pad.l, x2: pad.l + plotW, y1: y(spec.target), y2: y(spec.target),
        stroke: COLORS.teal, 'stroke-width': 1.5, 'stroke-dasharray': '5 4'
      }));
      svg.appendChild(el('text', {
        x: pad.l + plotW, y: y(spec.target) - 5, 'text-anchor': 'end',
        'font-size': 10.5, fill: COLORS.teal
      }, spec.targetLabel || 'target'));
    }

    var barCount = series.filter(function (s) { return s.type === 'bar'; }).length;
    var barSeen = 0;

    // series
    series.forEach(function (s) {
      var color = s.color || COLORS.amber;
      var pos = s.type === 'bar' ? xBand : x;

      if (s.band && s.band.length) {
        var up = [], down = [];
        s.band.forEach(function (b, i) {
          if (!b) return;
          up.push(pos(i) + ',' + y(b.high));
          down.unshift(pos(i) + ',' + y(b.low));
        });
        if (up.length) {
          svg.appendChild(el('polygon', {
            points: up.concat(down).join(' '), fill: color, opacity: 0.13
          }));
        }
      }

      if (s.type === 'bar') {
        var slot = plotW / Math.max(n, 1);
        var groupW = Math.max(Math.min(slot - 3, 30), 2);
        var bw = barCount > 1 ? Math.max(groupW / barCount - 1, 1.5) : groupW;
        var shift = barCount > 1 ? (barSeen - (barCount - 1) / 2) * (bw + 1) : 0;
        barSeen += 1;
        (s.values || []).forEach(function (v, i) {
          if (v === null) return;
          var isHot = s.flags && s.flags[i];
          svg.appendChild(el('rect', {
            x: pos(i) + shift - bw / 2, y: y(v), width: bw,
            height: Math.max(pad.t + plotH - y(v), 1),
            fill: isHot ? (s.flagColor || COLORS.red) : color,
            rx: 2, opacity: s.opacity || 1
          }));
        });
      } else {
        var pts = [];
        (s.values || []).forEach(function (v, i) { if (v !== null) pts.push(pos(i) + ',' + y(v)); });
        if (!pts.length) return;
        if (s.fill) {
          var first = (s.values || []).findIndex(function (v) { return v !== null; });
          var lastIdx = (s.values || []).length - 1;
          while (lastIdx >= 0 && s.values[lastIdx] === null) lastIdx--;
          svg.appendChild(el('polygon', {
            points: pos(first) + ',' + y(0) + ' ' + pts.join(' ') + ' ' + pos(lastIdx) + ',' + y(0),
            fill: color, opacity: s.fillOpacity || 0.12
          }));
        }
        svg.appendChild(el('polyline', {
          points: pts.join(' '), fill: 'none', stroke: color,
          'stroke-width': s.width || 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round',
          'stroke-dasharray': s.dashed ? '6 5' : null, opacity: s.opacity || 1
        }));
        if (s.dots) {
          (s.values || []).forEach(function (v, i) {
            if (v === null) return;
            var hot = s.flags && s.flags[i];
            if (!hot && s.dots !== 'all') return;
            svg.appendChild(el('circle', {
              cx: pos(i), cy: y(v), r: hot ? 4.5 : 2.6,
              fill: hot ? (s.flagColor || COLORS.red) : color,
              stroke: '#fff', 'stroke-width': hot ? 1.5 : 0
            }));
          });
        }
      }
    });

    // x labels
    var every = Math.max(1, Math.ceil(n / Math.max(Math.floor(width / (spec.rotate ? 44 : 72)), 2)));
    var lastDrawn = -Infinity;
    labels.forEach(function (label, i) {
      if (i % every !== 0 && i !== n - 1) return;
      if (i === n - 1 && n > 1 && (n - 1) - lastDrawn < every * 0.6) return;
      lastDrawn = i;
      var px = (series[0] && series[0].type === 'bar') ? xBand(i) : x(i);
      var text = spec.rotate && label.length > 12 ? label.slice(0, 11) + '\u2026' : label;
      var baseY = height - (spec.rotate ? 34 : 8);
      var node = el('text', {
        x: px, y: baseY, 'text-anchor': spec.rotate ? 'end' : 'middle',
        'font-size': spec.rotate ? 10.5 : 11, fill: textColor
      }, text);
      if (spec.rotate) node.setAttribute('transform', 'rotate(-32 ' + px + ' ' + baseY + ')');
      svg.appendChild(node);
    });

    // axis base
    svg.appendChild(el('line', {
      x1: pad.l, x2: pad.l + plotW, y1: pad.t + plotH, y2: pad.t + plotH,
      stroke: axisColor, 'stroke-width': 1
    }));
    if (spec.yLabel) {
      svg.appendChild(el('text', {
        x: pad.l - 8, y: pad.t - 3, 'text-anchor': 'end', 'font-size': 10.5, fill: textColor
      }, spec.yLabel));
    }

    // hover
    var marker = el('line', {
      x1: 0, x2: 0, y1: pad.t, y2: pad.t + plotH, stroke: spec.dark ? '#cfdcdc' : COLORS.ink,
      'stroke-width': 1, opacity: 0
    });
    svg.appendChild(marker);
    var hit = el('rect', {
      x: pad.l, y: pad.t, width: plotW, height: plotH, fill: 'transparent',
      style: 'cursor:crosshair'
    });
    svg.appendChild(hit);

    var tip = ensureTip(container);
    function move(event) {
      var box = svg.getBoundingClientRect();
      var scale = width / box.width;
      var px = (event.clientX - box.left) * scale;
      var isBar = series[0] && series[0].type === 'bar';
      var idx = isBar
        ? Math.floor(((px - pad.l) / plotW) * n)
        : Math.round(((px - pad.l) / plotW) * (n - 1));
      idx = Math.max(0, Math.min(n - 1, idx));
      var cx = isBar ? xBand(idx) : x(idx);
      marker.setAttribute('x1', cx);
      marker.setAttribute('x2', cx);
      marker.setAttribute('opacity', 0.28);
      var lines = ['<b>' + (spec.tipLabels ? spec.tipLabels[idx] : labels[idx]) + '</b>'];
      series.forEach(function (s) {
        var v = (s.values || [])[idx];
        if (v === null || v === undefined) return;
        lines.push((s.name ? s.name + ': ' : '') + fmt(v) + (spec.unit || ' kWh'));
      });
      if (spec.tipExtra && spec.tipExtra[idx]) lines.push(spec.tipExtra[idx]);
      tip.innerHTML = lines.join('<br>');
      tip.style.left = (cx / scale) + 'px';
      tip.style.top = (pad.t + 6) / scale + 'px';
      tip.style.opacity = 1;
    }
    hit.addEventListener('mousemove', move);
    hit.addEventListener('touchstart', function (e) { move(e.touches[0]); }, { passive: true });
    hit.addEventListener('touchmove', function (e) { move(e.touches[0]); }, { passive: true });
    hit.addEventListener('mouseleave', function () {
      tip.style.opacity = 0; marker.setAttribute('opacity', 0);
    });

    return svg;
  }

  // -------------------------------------------------------------------- donut

  function drawDonut(container, spec, width) {
    var size = Math.min(width, spec.height || 240);
    var svg = el('svg', {
      viewBox: '0 0 ' + size + ' ' + size, width: size, height: size,
      role: 'img', 'aria-label': spec.ariaLabel || 'share of consumption'
    });
    var cx = size / 2, cy = size / 2;
    var outer = size * 0.42, inner = size * 0.26;
    var total = (spec.slices || []).reduce(function (sum, s) { return sum + s.value; }, 0) || 1;
    var angle = -Math.PI / 2;
    var tip = ensureTip(container);

    (spec.slices || []).forEach(function (slice) {
      var sweep = (slice.value / total) * Math.PI * 2;
      var end = angle + sweep;
      var large = sweep > Math.PI ? 1 : 0;
      var p = [
        'M', cx + outer * Math.cos(angle), cy + outer * Math.sin(angle),
        'A', outer, outer, 0, large, 1, cx + outer * Math.cos(end), cy + outer * Math.sin(end),
        'L', cx + inner * Math.cos(end), cy + inner * Math.sin(end),
        'A', inner, inner, 0, large, 0, cx + inner * Math.cos(angle), cy + inner * Math.sin(angle),
        'Z'
      ].join(' ');
      var path = el('path', { d: p, fill: slice.color, stroke: '#fff', 'stroke-width': 1.5 });
      path.style.cursor = 'pointer';
      var mid = angle + sweep / 2;
      path.addEventListener('mouseenter', function () {
        tip.innerHTML = '<b>' + slice.label + '</b><br>' + fmt(slice.value) + ' kWh &middot; ' +
          (slice.value / total * 100).toFixed(1) + '%';
        var box = svg.getBoundingClientRect();
        var scale = size / box.width;
        tip.style.left = ((cx + (outer * 0.8) * Math.cos(mid)) / scale) + 'px';
        tip.style.top = ((cy + (outer * 0.8) * Math.sin(mid)) / scale) + 'px';
        tip.style.opacity = 1;
      });
      path.addEventListener('mouseleave', function () { tip.style.opacity = 0; });
      svg.appendChild(path);
      angle = end;
    });

    svg.appendChild(el('text', {
      x: cx, y: cy - 2, 'text-anchor': 'middle', 'font-size': size * 0.115,
      'font-weight': 600, fill: COLORS.ink
    }, spec.centerValue || fmt(total)));
    svg.appendChild(el('text', {
      x: cx, y: cy + size * 0.085, 'text-anchor': 'middle', 'font-size': size * 0.055,
      fill: COLORS.muted
    }, spec.centerLabel || 'kWh total'));
    return svg;
  }

  // -------------------------------------------------------------------- gauge

  function drawGauge(container, spec, width) {
    var w = Math.min(width, 260);
    var h = w * 0.62;
    var svg = el('svg', { viewBox: '0 0 ' + w + ' ' + h, width: w, height: h, role: 'img',
      'aria-label': 'score ' + spec.value + ' out of ' + (spec.max || 100) });
    var cx = w / 2, cy = h * 0.92, r = w * 0.38, thickness = w * 0.085;
    var value = Math.max(0, Math.min(spec.value, spec.max || 100));
    var frac = value / (spec.max || 100);

    function arc(from, to, color, op) {
      var a0 = Math.PI + Math.PI * from, a1 = Math.PI + Math.PI * to;
      var large = (to - from) > 1 ? 1 : 0;
      return el('path', {
        d: ['M', cx + r * Math.cos(a0), cy + r * Math.sin(a0),
            'A', r, r, 0, large, 1, cx + r * Math.cos(a1), cy + r * Math.sin(a1)].join(' '),
        fill: 'none', stroke: color, 'stroke-width': thickness,
        'stroke-linecap': 'round', opacity: op || 1
      });
    }
    svg.appendChild(arc(0, 1, COLORS.soft));
    if (frac > 0.01) svg.appendChild(arc(0, frac, spec.color || COLORS.teal));
    svg.appendChild(el('text', {
      x: cx, y: cy - h * 0.14, 'text-anchor': 'middle', 'font-size': w * 0.2,
      'font-weight': 600, fill: COLORS.ink
    }, String(Math.round(value))));
    svg.appendChild(el('text', {
      x: cx, y: cy - h * 0.02, 'text-anchor': 'middle', 'font-size': w * 0.062, fill: COLORS.muted
    }, spec.label || ('of ' + (spec.max || 100))));
    return svg;
  }

  // ------------------------------------------------------------------ public

  function render(container, spec) {
    if (!container) return;
    container.classList.add('chart');
    container._spec = spec;
    var width = Math.max(container.clientWidth || container.offsetWidth || 560, 260);
    var old = container.querySelector('svg');
    if (old) old.remove();
    var svg;
    if (spec.type === 'donut') svg = drawDonut(container, spec, width);
    else if (spec.type === 'gauge') svg = drawGauge(container, spec, width);
    else svg = drawCartesian(container, spec, width);
    container.insertBefore(svg, container.firstChild);

    if (!container._observed && global.ResizeObserver) {
      container._observed = true;
      var timer;
      new ResizeObserver(function () {
        clearTimeout(timer);
        timer = setTimeout(function () {
          if (container._spec && container.isConnected) render(container, container._spec);
        }, 120);
      }).observe(container);
    }
  }

  global.SEChart = { render: render, colors: COLORS, format: fmt };
})(window);
