/* Hash router and shell wiring. */

(function (global) {
  'use strict';

  var state = {
    range: 'month',
    view: 'daily',
    start: '',
    end: '',
    sensitivity: 'normal',
    reportDays: '30',
    billKwh: null
  };

  var current = 'dashboard';

  var view = document.getElementById('view');
  var titleNode = document.getElementById('page-title');
  var subNode = document.getElementById('page-sub');
  var controlsNode = document.getElementById('page-controls');

  function routeName() {
    var hash = (location.hash || '#/dashboard').replace('#/', '');
    return Pages[hash] ? hash : 'dashboard';
  }

  function markNav(name) {
    Array.prototype.forEach.call(document.querySelectorAll('#nav a'), function (link) {
      link.classList.toggle('active', link.getAttribute('href') === '#/' + name);
    });
  }

  function render() {
    current = routeName();
    var page = Pages[current];
    markNav(current);
    titleNode.textContent = page.title;
    subNode.textContent = 'Loading\u2026';
    controlsNode.innerHTML = page.controls ? page.controls(state) : '';
    view.innerHTML = '<div class="skeleton"></div>';

    page.load(state).then(function (data) {
      view.innerHTML = '';
      page.render(view, data, state);
      subNode.textContent = page.sub ? page.sub(data, state) : '';
      view.scrollTop = 0;
    }).catch(function (err) {
      subNode.textContent = 'Could not load this page';
      view.innerHTML = '<div class="error"><b>' + UI.esc(err.message) + '</b><br>' +
        'If the server is running, check its console for the error and reload this page.</div>';
    });
  }

  controlsNode.addEventListener('click', function (event) {
    var button = event.target.closest('button[data-value]');
    if (!button) return;
    var group = button.closest('[data-seg]');
    if (!group) return;
    state[group.getAttribute('data-seg')] = button.getAttribute('data-value');
    render();
  });

  window.addEventListener('hashchange', render);

  global.App = {
    reload: render,
    state: state
  };

  API.health().then(function (h) {
    document.getElementById('foot-status').textContent =
      'v' + h.version + ' \u00b7 ' + h.hourly_readings.toLocaleString() + ' readings \u00b7 ' +
      (h.ai.enabled ? 'AI on' : 'AI off');
  }).catch(function () {
    document.getElementById('foot-status').textContent = 'server unreachable';
  });

  render();
})(window);
