/* Thin wrapper over fetch. Every call returns parsed JSON or throws an Error
   carrying a message the interface can show as-is. */

(function (global) {
  'use strict';

  function request(path, options) {
    return fetch(path, options).then(function (response) {
      return response.text().then(function (body) {
        var data;
        try { data = body ? JSON.parse(body) : {}; } catch (err) { data = { raw: body }; }
        if (!response.ok) {
          throw new Error(data.error || ('Request failed: ' + response.status + ' ' + path));
        }
        return data;
      });
    }, function () {
      throw new Error('Cannot reach the server. Start it with "python run.py" and reload.');
    });
  }

  function get(path, params) {
    var query = '';
    if (params) {
      var parts = [];
      for (var key in params) {
        if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
          parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(params[key]));
        }
      }
      if (parts.length) query = '?' + parts.join('&');
    }
    return request(path + query);
  }

  function post(path, body) {
    return request(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
  }

  global.API = {
    health: function () { return get('/api/health'); },
    overview: function (range) { return get('/api/overview', { range: range }); },
    consumption: function (params) { return get('/api/consumption', params); },
    appliances: function (days) { return get('/api/appliances', { days: days }); },
    insights: function (useAi) { return get('/api/insights', { ai: useAi ? 1 : 0 }); },
    predictions: function () { return get('/api/predictions'); },
    anomalies: function (params) { return get('/api/anomalies', params); },
    recommendations: function () { return get('/api/recommendations'); },
    report: function (days) { return get('/api/reports/summary', { days: days }); },
    settings: function () { return get('/api/settings'); },
    saveSettings: function (body) { return post('/api/settings', body); },
    resetSettings: function () { return post('/api/settings/reset'); },
    regenerate: function () { return post('/api/demo/regenerate'); },
    estimateBill: function (body) { return post('/api/bill/estimate', body); },
    ask: function (question) { return post('/api/ai/ask', { question: question }); }
  };
})(window);
