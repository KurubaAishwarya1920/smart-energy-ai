/* Page renderers. Each page exposes:
     title   - shown in the top bar
     sub(d)  - one line of context under the title
     controls(state) - optional HTML for the top-bar controls
     load(state)     - returns a promise of the data the page needs
     render(root, data, state) - writes the page and draws its charts       */

(function (global) {
  'use strict';

  var C = SEChart.colors;
  var PALETTE = ['#e8871e', '#0f766e', '#3f5f8f', '#c0392b', '#7a9e3f',
                 '#8a6bbf', '#d9a441', '#4f8f9e', '#9c6b4f'];

  function severityClass(sev) {
    return 'sev-' + (sev === 'critical' || sev === 'high' ? 'critical'
      : sev === 'warning' || sev === 'medium' ? 'warning' : 'info');
  }

  // =================================================================== DASHBOARD

  var dashboard = {
    title: 'Dashboard',
    sub: function (d) {
      return 'Sample household \u00b7 ' + d.totals.lifetime_kwh.toLocaleString() +
        ' kWh recorded \u00b7 updated ' + UI.timeAgo(d.generated_at);
    },
    controls: function (state) {
      return UI.segmented('range', [
        { value: 'day', label: 'Day' },
        { value: 'week', label: 'Week' },
        { value: 'month', label: 'Month' },
        { value: 'year', label: 'Year' }
      ], state.range);
    },
    load: function (state) { return API.overview(state.range); },
    render: function (root, d, state) {
      UI.setCurrency(d.currency_symbol);
      var t = d.totals;
      var rangeWord = { day: 'today', week: 'this week', month: 'in 30 days', year: 'this year' }[state.range];
      var insight = d.headline_insight;
      var alerts = (d.alerts || []).filter(function (a) {
        return !insight || a.title !== insight.title;
      });

      root.innerHTML =
        '<section class="hero">' +
          '<div class="readout">' +
            '<span class="k">Used so far today</span>' +
            '<span class="big">' + UI.num(t.today_kwh, 2) + '<small>kWh</small></span>' +
            '<span class="note">' + t.today_hours + ' hours recorded \u00b7 ' +
              UI.money(t.today_kwh * (d.bill.effective_rate || 0)) + ' at your tariff</span>' +
          '</div>' +
          '<div class="chartwrap">' +
            '<div class="legend"><span><i class="swatch" style="background:#f0a44e"></i>Today</span>' +
            '<span><i class="swatch" style="background:#7e9ba3"></i>Typical day</span>' +
            '<span><i class="swatch" style="background:rgba(232,135,30,.35)"></i>Peak hours</span></div>' +
            UI.chartBox('hero-chart', 190) +
          '</div>' +
        '</section>' +

        '<section class="grid cols-4">' +
          UI.tile({ label: 'Consumption ' + rangeWord, value: UI.num(t.range_kwh, 1), unit: 'kWh',
                    accent: 'accent', foot: t.range_change_percent === null ? 'No earlier period to compare'
                      : UI.delta(t.range_change_percent) + ' against the previous period' }) +
          UI.tile({ label: 'Estimated bill this month', value: UI.money(d.bill.total),
                    foot: UI.num(t.projected_month_kwh, 0) + ' kWh projected \u00b7 estimate only' }) +
          UI.tile({ label: 'Average daily usage', value: UI.num(t.avg_daily_kwh, 2), unit: 'kWh',
                    foot: 'Across the selected period' }) +
          UI.tile({ label: 'Peak hourly draw', value: UI.num(t.peak_kwh, 2), unit: 'kWh',
                    foot: t.peak_hour === null ? '' : UI.hourLabel(t.peak_hour) + ' on ' + UI.dayLabel(t.peak_date) }) +
        '</section>' +

        '<section class="grid split">' +
          '<div class="card">' +
            '<header><h2>' + (state.range === 'day' ? 'Today, hour by hour' : 'Consumption trend') +
            '</h2><span class="spacer"></span>' +
            '<span class="legend"><span><i class="swatch" style="background:#e8871e"></i>' +
            (state.range === 'day' ? 'Today' : 'This period') + '</span>' +
            '<span><i class="swatch" style="background:#b6c5c5"></i>' +
            (state.range === 'day' ? 'Typical day' : 'Previous period') + '</span></span></header>' +
            UI.chartBox('trend-chart', 260) +
          '</div>' +
          '<div class="card">' +
            '<header><h2>Efficiency score</h2></header>' +
            UI.chartBox('score-gauge', 160) +
            '<p class="hint" style="text-align:center;margin-top:-6px">' + UI.esc(d.efficiency.band) + '</p>' +
            '<div style="margin-top:12px">' + d.efficiency.components.map(function (c) {
              return '<div style="margin-bottom:10px">' +
                '<div style="display:flex;justify-content:space-between;font-size:.84rem">' +
                  '<span>' + UI.esc(c.label) + '</span><b>' + c.points + '/' + c.max + '</b></div>' +
                '<div class="bar-meter"><i style="width:' + (c.points / c.max * 100) + '%;background:' +
                  (c.points / c.max > 0.75 ? '#0f766e' : c.points / c.max > 0.45 ? '#e8871e' : '#c0392b') +
                  '"></i></div>' +
                '<div class="hint" style="font-size:.76rem">' + UI.esc(c.detail) + '</div></div>';
            }).join('') + '</div>' +
          '</div>' +
        '</section>' +

        '<section class="grid cols-4">' +
          UI.tile({ label: 'CO\u2082 this month', value: UI.num(t.month_co2_kg, 0), unit: 'kg',
                    accent: 'accent-teal',
                    foot: t.trees_equivalent + ' trees would offset a year at this rate' }) +
          UI.tile({ label: 'Energy used this month', value: UI.num(t.month_kwh, 1), unit: 'kWh',
                    foot: 'Target ' + UI.num(d.target_month_kwh, 0) + ' kWh' }) +
          UI.tile({ label: 'Lifetime recorded', value: UI.num(t.lifetime_kwh, 0), unit: 'kWh',
                    foot: 'Since demo history begins' }) +
          UI.tile({ label: 'Efficiency', value: d.efficiency.score + '<small>/100</small>',
                    accent: d.efficiency.score >= 70 ? 'accent-teal' : 'accent',
                    foot: UI.esc(d.efficiency.band) }) +
        '</section>' +

        '<section class="grid split">' +
          '<div class="card">' +
            '<header><h2>What the data is telling you</h2>' +
            '<span class="spacer"></span><span class="badge">Rule engine \u00b7 offline</span></header>' +
            (insight ?
              '<div class="entry ' + severityClass(insight.severity) + '">' +
                '<i class="rail"></i><div class="body">' +
                  '<h3>' + UI.esc(insight.title) + '</h3>' +
                  '<p>' + UI.esc(insight.explanation) + '</p>' +
                  '<div class="action"><b>Do this:</b> ' + UI.esc(insight.action) + '</div>' +
                '</div><div class="money"><span class="amt">' + UI.money(insight.saving_cost) +
                '</span><span class="cap">possible monthly saving</span></div></div>'
              : '<p class="empty">No insight yet.</p>') +
            '<p class="hint" style="margin-top:12px"><a href="#/insights">See all insights</a></p>' +
          '</div>' +
          '<div class="card">' +
            '<header><h2>Recent alerts</h2></header>' +
            (alerts.length ? alerts.map(function (a) {
              return '<div style="display:flex;gap:10px;align-items:baseline;padding:7px 0;border-bottom:1px solid var(--line)">' +
                UI.severityBadge(a.severity) +
                '<span style="font-size:.87rem">' + UI.esc(a.title) + '</span></div>';
            }).join('') : '<p class="empty">Nothing needs your attention.</p>') +
          '</div>' +
        '</section>' +

        '<p class="notice"><b>Demo data.</b> These figures come from a generated sample household, ' +
        'not from a real meter. Swap in your own readings and every number on this page updates.</p>';

      var peakStart = 18, peakEnd = 21;
      SEChart.render(document.getElementById('hero-chart'), {
        type: 'area', height: 190, dark: true,
        labels: d.typical_profile.map(function (_, i) { return UI.hourLabel(i); }),
        highlight: { from: peakStart, to: peakEnd, label: 'peak', color: 'rgba(232,135,30,.16)' },
        series: [
          { values: d.typical_profile, color: '#7e9ba3', width: 1.6, opacity: .85 },
          { values: d.today_profile, color: '#f0a44e', fill: true, fillOpacity: .22, width: 2.4, dots: 'all' }
        ]
      });

      if (state.range === 'day') {
        SEChart.render(document.getElementById('trend-chart'), {
          type: 'area', height: 260,
          labels: d.typical_profile.map(function (_, i) { return UI.hourLabel(i); }),
          highlight: { from: peakStart, to: peakEnd, label: 'peak' },
          series: [
            { name: 'Typical', values: d.typical_profile, color: '#b6c5c5', width: 1.6 },
            { name: 'Today', values: d.today_profile, color: '#e8871e', fill: true, width: 2.2 }
          ]
        });
      } else {
        var labels = d.trend.map(function (r) { return UI.dayLabel(r.date); });
        var prev = d.previous_trend.map(function (r) { return r.kwh; });
        while (prev.length < labels.length) prev.unshift(null);
        SEChart.render(document.getElementById('trend-chart'), {
          type: 'line', height: 260, labels: labels,
          tipLabels: d.trend.map(function (r) { return UI.fullDate(r.date); }),
          series: [
            { name: 'Previous', values: prev.slice(-labels.length), color: '#b6c5c5', width: 1.6 },
            { name: 'Current', values: d.trend.map(function (r) { return r.kwh; }),
              color: '#e8871e', fill: true, width: 2.2 }
          ]
        });
      }

      SEChart.render(document.getElementById('score-gauge'), {
        type: 'gauge', value: d.efficiency.score, max: 100,
        color: d.efficiency.score >= 70 ? '#0f766e' : d.efficiency.score >= 55 ? '#e8871e' : '#c0392b',
        label: 'out of 100'
      });
    }
  };

  // ================================================================ CONSUMPTION

  var consumption = {
    title: 'Energy consumption',
    sub: function (d) {
      return d.summary.days + ' days \u00b7 ' + UI.num(d.summary.total_kwh, 1) + ' kWh \u00b7 ' +
        UI.money(d.summary.cost) + ' estimated';
    },
    controls: function (state) {
      return UI.segmented('view', [
        { value: 'daily', label: 'Daily' },
        { value: 'weekly', label: 'Weekly' },
        { value: 'monthly', label: 'Monthly' }
      ], state.view);
    },
    load: function (state) {
      return API.consumption({ view: state.view, start: state.start, end: state.end });
    },
    render: function (root, d, state) {
      UI.setCurrency(d.currency_symbol);
      var s = d.summary;
      var labels = d.series.map(function (r) {
        return state.view === 'daily' ? UI.dayLabel(r.label) : r.label.replace('Week of ', '');
      });
      var values = d.series.map(function (r) { return r.kwh; });
      var avg = s.avg_kwh * (state.view === 'daily' ? 1 : (d.series[0] ? d.series[0].days : 1));

      root.innerHTML =
        '<section class="card no-print">' +
          '<header><h2>Date range</h2><span class="spacer"></span>' +
          '<span class="hint">Leave blank for the most recent period</span></header>' +
          '<div class="grid cols-4" style="align-items:end">' +
            '<div class="field"><label for="start">From</label><input type="date" id="start" value="' +
              (state.start || '') + '"></div>' +
            '<div class="field"><label for="end">To</label><input type="date" id="end" value="' +
              (state.end || '') + '"></div>' +
            '<div class="field"><label>&nbsp;</label><button class="btn primary" id="apply-range">Apply range</button></div>' +
            '<div class="field"><label>&nbsp;</label><button class="btn" id="clear-range">Clear</button></div>' +
          '</div>' +
        '</section>' +

        '<section class="grid cols-4">' +
          UI.tile({ label: 'Total consumption', value: UI.num(s.total_kwh, 1), unit: 'kWh', accent: 'accent',
                    foot: s.change_percent === null ? 'No earlier period' :
                      UI.delta(s.change_percent) + ' vs previous ' + s.days + ' days' }) +
          UI.tile({ label: 'Estimated cost', value: UI.money(s.cost), foot: 'Across ' + s.days + ' days' }) +
          UI.tile({ label: 'Highest day', value: UI.num(s.max_kwh, 2), unit: 'kWh', foot: 'Lowest ' + UI.num(s.min_kwh, 2) + ' kWh' }) +
          UI.tile({ label: 'Daily average', value: UI.num(s.avg_kwh, 2), unit: 'kWh', foot: 'Per day in this range' }) +
        '</section>' +

        '<section class="card">' +
          '<header><h2>' + (state.view === 'daily' ? 'Daily' : state.view === 'weekly' ? 'Weekly' : 'Monthly') +
          ' consumption</h2><span class="spacer"></span>' +
          '<span class="legend"><span><i class="swatch" style="background:#e8871e"></i>kWh</span>' +
          '<span><i class="swatch" style="background:#0f766e"></i>average</span></span></header>' +
          UI.chartBox('bars', 280) +
        '</section>' +

        '<section class="grid cols-2">' +
          '<div class="card"><header><h2>Trend</h2></header>' + UI.chartBox('area', 240) + '</div>' +
          '<div class="card"><header><h2>Typical day shape</h2>' +
            '<span class="spacer"></span><span class="hint">average kWh per hour</span></header>' +
            UI.chartBox('profile', 240) + '</div>' +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Reading log</h2><span class="spacer"></span>' +
          '<a class="btn no-print" href="/api/export/consumption.csv?days=180">Download CSV</a></header>' +
          UI.table(['Date', 'Day', 'Consumed (kWh)', 'Est. cost', 'Peak hour', 'Peak (kWh)', 'Avg per hour', 'Status'],
            d.detail.map(function (r) {
              return [
                UI.esc(r.date) + (r.partial ? ' <span class="badge">partial</span>' : ''),
                UI.esc(r.day_name),
                '<b>' + UI.num(r.kwh, 2) + '</b>',
                UI.money(r.cost),
                UI.hourLabel(r.peak_hour),
                UI.num(r.peak_kwh, 2),
                UI.num(r.avg_hourly_kwh, 2),
                UI.statusBadge(r.status)
              ];
            })) +
        '</section>';

      SEChart.render(document.getElementById('bars'), {
        type: 'bar', height: 280, labels: labels, rotate: labels.length > 14,
        target: avg, targetLabel: 'average',
        series: [{ type: 'bar', values: values, color: '#e8871e',
                   flags: values.map(function (v) { return v > avg * 1.25; }), flagColor: '#c0392b' }]
      });

      SEChart.render(document.getElementById('area'), {
        type: 'area', height: 240, labels: labels,
        series: [{ values: values, color: '#3f5f8f', fill: true, width: 2 }]
      });

      SEChart.render(document.getElementById('profile'), {
        type: 'area', height: 240,
        labels: d.typical_profile.map(function (_, i) { return UI.hourLabel(i); }),
        highlight: { from: 18, to: 21, label: 'peak' },
        series: [{ values: d.typical_profile, color: '#0f766e', fill: true, width: 2 }]
      });

      document.getElementById('apply-range').addEventListener('click', function () {
        state.start = document.getElementById('start').value;
        state.end = document.getElementById('end').value;
        global.App.reload();
      });
      document.getElementById('clear-range').addEventListener('click', function () {
        state.start = ''; state.end = ''; global.App.reload();
      });
    }
  };

  // =================================================================== INSIGHTS

  var insights = {
    title: 'AI energy insights',
    sub: function (d) {
      return d.insights.length + ' findings \u00b7 up to ' + UI.money(d.total_saving_cost) +
        ' a month identified';
    },
    load: function () { return API.insights(true); },
    render: function (root, d) {
      var ai = d.ai || { enabled: false, message: '' };
      root.innerHTML =
        '<section class="card">' +
          '<header><h2>Summary</h2><span class="spacer"></span>' +
          '<span class="badge ' + (ai.enabled ? 'ok' : '') + '">' +
            (ai.enabled ? 'AI: ' + UI.esc(ai.provider) : 'Offline rule engine') + '</span></header>' +
          (d.narrative ? '<p>' + UI.esc(d.narrative) + '</p>'
            : '<p>' + UI.esc(ai.message) + '</p>') +
          (d.narrative_error ? '<p class="hint">' + UI.esc(d.narrative_error) + '</p>' : '') +
          '<div class="grid cols-3" style="margin-top:8px">' +
            UI.tile({ label: 'Findings', value: d.insights.length, foot: 'From your own data' }) +
            UI.tile({ label: 'Identified saving', value: UI.money(d.total_saving_cost),
                      accent: 'accent-teal', foot: 'Per month, if acted on' }) +
            UI.tile({ label: 'Energy at stake', value: UI.num(d.total_saving_kwh, 0), unit: 'kWh',
                      foot: 'Per month' }) +
          '</div>' +
        '</section>' +

        '<section class="card no-print">' +
          '<header><h2>Ask about your usage</h2></header>' +
          '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
            '<input id="ask-q" class="field" style="flex:1 1 320px;border:1px solid var(--line-strong);border-radius:6px;padding:8px 10px" ' +
              'placeholder="Why is my evening usage so high?">' +
            '<button class="btn primary" id="ask-btn">Ask</button></div>' +
          '<div id="ask-out" class="hint" style="margin-top:10px">' +
            (ai.enabled ? 'Answers come from ' + UI.esc(ai.model || ai.provider) + '.'
              : 'Question answering needs an AI provider. The insights below work without one \u2014 see .env.example to switch it on.') +
          '</div>' +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Findings</h2><span class="spacer"></span>' +
          '<span class="hint">Sorted by severity, then by money at stake</span></header>' +
          d.insights.map(function (i) {
            return '<div class="entry ' + severityClass(i.severity) + '">' +
              '<i class="rail"></i>' +
              '<div class="body">' +
                '<h3>' + UI.esc(i.title) + ' ' + UI.severityBadge(i.severity) + '</h3>' +
                '<p>' + UI.esc(i.explanation) + '</p>' +
                '<div class="action"><b>Do this:</b> ' + UI.esc(i.action) + '</div>' +
              '</div>' +
              '<div class="money"><span class="amt">' + (i.saving_cost ? UI.money(i.saving_cost) : '\u2014') +
                '</span><span class="cap">' + (i.saving_kwh ? UI.num(i.saving_kwh, 0) + ' kWh a month' : 'no direct saving') +
              '</span></div></div>';
          }).join('') +
        '</section>' +
        '<p class="notice"><b>How this works.</b> ' + UI.esc(d.note) + ' Savings are estimates, not guarantees.</p>';

      var button = document.getElementById('ask-btn');
      var input = document.getElementById('ask-q');
      var out = document.getElementById('ask-out');
      function ask() {
        var question = input.value.trim();
        if (!question) { input.focus(); return; }
        button.disabled = true;
        out.textContent = 'Thinking\u2026';
        API.ask(question).then(function (res) {
          out.textContent = res.answer || res.message || 'No answer available.';
        }).catch(function (err) {
          out.textContent = err.message;
        }).then(function () { button.disabled = false; });
      }
      button.addEventListener('click', ask);
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') ask(); });
    }
  };

  // ================================================================= PREDICTION

  var prediction = {
    title: 'Consumption prediction',
    sub: function (d) {
      return 'Confidence ' + d.confidence_percent + '%' +
        (d.accuracy ? ' \u00b7 average error ' + d.accuracy.mape_percent + '% over ' +
          d.accuracy.tested_days + ' tested days' : '');
    },
    load: function () { return API.predictions(); },
    render: function (root, d) {
      var history = d.history.map(function (r) { return r.kwh; });
      var forecastValues = d.forecast.slice(0, 21).map(function (r) { return r.kwh; });
      var labels = d.history.map(function (r) { return UI.dayLabel(r.date); })
        .concat(d.forecast.slice(0, 21).map(function (r) { return UI.dayLabel(r.date); }));

      var histSeries = history.concat(forecastValues.map(function () { return null; }));
      var foreSeries = history.map(function () { return null; });
      foreSeries[history.length - 1] = history[history.length - 1];
      foreSeries = foreSeries.concat(forecastValues);

      var margin = d.confidence_percent ? (100 - d.confidence_percent) / 100 : 0.15;
      var band = histSeries.map(function () { return null; });
      band[history.length - 1] = { low: history[history.length - 1], high: history[history.length - 1] };
      forecastValues.forEach(function (v, i) {
        var spread = v * margin * (1 + i * 0.03);
        band.push({ low: Math.max(v - spread, 0), high: v + spread });
      });

      root.innerHTML =
        '<section class="grid cols-4">' +
          UI.tile({ label: 'Tomorrow', value: UI.num(d.next_day.kwh, 1), unit: 'kWh', accent: 'accent',
                    foot: UI.num(d.next_day.low, 1) + ' to ' + UI.num(d.next_day.high, 1) + ' kWh \u00b7 ' +
                          UI.money(d.next_day.cost) }) +
          UI.tile({ label: 'Next 7 days', value: UI.num(d.next_week.kwh, 0), unit: 'kWh',
                    foot: UI.money(d.next_week.cost) + ' of energy charge' }) +
          UI.tile({ label: 'This month, projected', value: UI.num(d.month.kwh, 0), unit: 'kWh',
                    foot: UI.num(d.month.so_far_kwh, 0) + ' used, ' + UI.num(d.month.remaining_kwh, 0) +
                          ' expected over ' + d.month.days_remaining + ' days' }) +
          UI.tile({ label: 'Expected bill', value: UI.money(d.month.bill.total), accent: 'accent-teal',
                    foot: 'Estimate at your configured tariff' }) +
        '</section>' +

        '<section class="card">' +
          '<header><h2>History and forecast</h2><span class="spacer"></span>' +
          '<span class="legend"><span><i class="swatch" style="background:#10242e"></i>Measured</span>' +
          '<span><i class="swatch" style="background:#e8871e"></i>Forecast</span>' +
          '<span><i class="swatch" style="background:#f6d9b8"></i>Likely range</span></span></header>' +
          UI.chartBox('forecast-chart', 300) +
          '<p class="hint">' + UI.esc(d.disclaimer) + '</p>' +
        '</section>' +

        '<section class="grid split">' +
          '<div class="card"><header><h2>Next seven days</h2></header>' +
            UI.table(['Date', 'Day', 'Predicted (kWh)', 'Against target'],
              d.next_week.days.map(function (r) {
                var target = d.month.target_kwh / 30;
                var diff = (r.kwh - target) / target * 100;
                return [UI.esc(r.date),
                  new Date(r.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long' }),
                  '<b>' + UI.num(r.kwh, 2) + '</b>',
                  UI.delta(Math.round(diff * 10) / 10)];
              })) +
          '</div>' +
          '<div class="card"><header><h2>How confident is this?</h2></header>' +
            UI.chartBox('conf-gauge', 150) +
            '<p class="hint" style="text-align:center">Confidence comes from testing the model against ' +
              (d.accuracy ? d.accuracy.tested_days + ' days it had never seen' : 'recent days') + '.</p>' +
            '<p style="font-size:.86rem">' + UI.esc(d.method) + '</p>' +
            '<p class="hint">Month projection assumes the rest of the month behaves like the ' +
            'pattern in your history. A holiday, a heatwave or a house guest will move it.</p>' +
          '</div>' +
        '</section>';

      SEChart.render(document.getElementById('forecast-chart'), {
        type: 'line', height: 300, labels: labels,
        series: [
          { name: 'Measured', values: histSeries, color: '#10242e', width: 2 },
          { name: 'Forecast', values: foreSeries, color: '#e8871e', width: 2.4, dashed: true, band: band }
        ]
      });
      SEChart.render(document.getElementById('conf-gauge'), {
        type: 'gauge', value: d.confidence_percent, max: 100, label: 'confidence',
        color: d.confidence_percent >= 75 ? '#0f766e' : '#e8871e'
      });
    }
  };

  // ================================================================== ANOMALIES

  var anomalies = {
    title: 'Anomaly detection',
    sub: function (d) {
      return d.summary.events + ' events across ' + d.summary.days_analysed + ' days \u00b7 ' +
        UI.num(d.summary.excess_kwh, 1) + ' kWh of unexpected energy';
    },
    controls: function (state) {
      return UI.segmented('sensitivity', [
        { value: 'strict', label: 'Only the clear ones' },
        { value: 'normal', label: 'Balanced' },
        { value: 'loose', label: 'Catch everything' }
      ], state.sensitivity);
    },
    load: function (state) {
      var map = { strict: { day_z: 2.6, hour_z: 3.8 }, normal: { day_z: 2.0, hour_z: 3.0 },
                  loose: { day_z: 1.6, hour_z: 2.4 } };
      return API.anomalies(map[state.sensitivity] || map.normal);
    },
    render: function (root, d) {
      var s = d.summary;
      var flagged = {};
      d.events.forEach(function (e) { flagged[e.date] = true; });

      root.innerHTML =
        '<section class="grid cols-4">' +
          UI.tile({ label: 'Normal days', value: s.normal_days, accent: 'accent-teal',
                    foot: 'Out of ' + s.days_analysed + ' analysed' }) +
          UI.tile({ label: 'Unusual events', value: s.events, accent: 'accent-red',
                    foot: s.high + ' high \u00b7 ' + s.medium + ' medium \u00b7 ' + s.low + ' low' }) +
          UI.tile({ label: 'Excess energy', value: UI.num(s.excess_kwh, 1), unit: 'kWh',
                    foot: 'Above what the pattern predicted' }) +
          UI.tile({ label: 'Cost of the excess', value: UI.money(s.excess_cost), accent: 'accent',
                    foot: 'At your configured tariff' }) +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Where the outliers sit</h2><span class="spacer"></span>' +
          '<span class="legend"><span><i class="swatch" style="background:#e8871e"></i>Normal day</span>' +
          '<span><i class="swatch" style="background:#c0392b"></i>Flagged day</span></span></header>' +
          UI.chartBox('anom-chart', 280) +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Events</h2><span class="spacer"></span>' +
          '<span class="hint">Newest first</span></header>' +
          (d.events.length ? d.events.map(function (e) {
            return '<div class="entry ' + severityClass(e.severity) + '">' +
              '<i class="rail"></i>' +
              '<div class="body">' +
                '<h3>' + UI.esc(e.window) + ', ' + UI.dateOnly(e.date) + ' ' +
                  UI.severityBadge(e.severity) +
                  (e.appliance ? ' <span class="badge">' + UI.esc(e.appliance) + '</span>' : '') + '</h3>' +
                '<p>' + UI.esc(e.reason) + ' Measured ' + UI.num(e.kwh, 2) + ' kWh against an expected ' +
                  UI.num(e.expected_kwh, 2) + ' kWh (z-score ' + e.z_score + ').</p>' +
                '<div class="action"><b>Do this:</b> ' + UI.esc(e.action) + '</div>' +
              '</div>' +
              '<div class="money"><span class="amt" style="color:#c0392b">+' + UI.num(e.excess_kwh, 2) +
                ' kWh</span><span class="cap">about ' + UI.money(e.extra_cost) + ' extra</span></div></div>';
          }).join('') : '<p class="empty">No anomalies at this sensitivity. Loosen it to see borderline days.</p>') +
        '</section>' +

        '<p class="notice"><b>Method.</b> ' + UI.esc(d.method) + ' A z-score is how many standard ' +
        'deviations a reading sits from its own recent average, so the threshold adapts to how ' +
        'variable your usage already is.</p>';

      SEChart.render(document.getElementById('anom-chart'), {
        type: 'bar', height: 280,
        labels: d.daily.map(function (r) { return UI.dayLabel(r.date); }),
        tipLabels: d.daily.map(function (r) { return UI.fullDate(r.date); }),
        series: [{
          type: 'bar', values: d.daily.map(function (r) { return r.kwh; }), color: '#e8871e',
          flags: d.daily.map(function (r) { return !!flagged[r.date]; }), flagColor: '#c0392b'
        }]
      });
    }
  };

  // ================================================================= APPLIANCES

  var appliances = {
    title: 'Appliance analysis',
    sub: function (d) {
      return d.appliances.length + ' devices \u00b7 ' + UI.num(d.total_kwh, 1) + ' kWh over ' +
        d.period_days + ' days';
    },
    load: function () { return API.appliances(30); },
    render: function (root, d) {
      UI.setCurrency(d.currency_symbol);
      var top = d.appliances[0];
      var slices = d.appliances.map(function (a, i) {
        return { label: a.name, value: a.kwh, color: PALETTE[i % PALETTE.length] };
      });

      root.innerHTML =
        '<section class="grid cols-4">' +
          UI.tile({ label: 'Biggest load', value: UI.esc(top.name), accent: 'accent',
                    foot: top.share_percent + '% of everything you use' }) +
          UI.tile({ label: 'Its monthly energy', value: UI.num(top.monthly_kwh, 0), unit: 'kWh',
                    foot: 'About ' + UI.money(top.monthly_cost) + ' a month' }) +
          UI.tile({ label: 'Devices tracked', value: d.appliances.length,
                    foot: 'Modelled from load profiles' }) +
          UI.tile({ label: 'Total monthly cost', value: UI.money(d.total_monthly_cost),
                    foot: 'Sum of appliance estimates' }) +
        '</section>' +

        '<section class="grid split">' +
          '<div class="card"><header><h2>Ranking by consumption</h2></header>' +
            UI.table(['#', 'Appliance', 'Share', 'kWh / month', 'Hours / day', 'Est. cost', 'Rating'],
              d.appliances.map(function (a) {
                return [
                  '<span class="rank"><span class="n' + (a.rank === 1 ? ' top' : '') + '">' + a.rank + '</span></span>',
                  '<b>' + UI.esc(a.name) + '</b><br><span class="hint">' + UI.esc(a.category) +
                    ' \u00b7 ' + a.rated_w + ' W</span>',
                  '<div style="display:flex;align-items:center;gap:8px;justify-content:flex-end">' +
                    '<div class="bar-meter" style="width:70px"><i style="width:' +
                    Math.min(a.share_percent * 2.2, 100) + '%"></i></div>' + a.share_percent + '%</div>',
                  UI.num(a.monthly_kwh, 1),
                  UI.num(a.hours_per_day, 1),
                  UI.money(a.monthly_cost),
                  UI.statusBadge(a.efficiency)
                ];
              })) +
          '</div>' +
          '<div class="card"><header><h2>Share of consumption</h2></header>' +
            '<div style="display:flex;justify-content:center">' + UI.chartBox('donut', 240) + '</div>' +
            '<div class="legend" style="margin-top:10px">' + slices.map(function (s) {
              return '<span><i class="swatch" style="background:' + s.color + '"></i>' +
                UI.esc(s.label) + '</span>';
            }).join('') + '</div>' +
          '</div>' +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Against a typical home this size</h2><span class="spacer"></span>' +
          '<span class="legend"><span><i class="swatch" style="background:#e8871e"></i>You</span>' +
          '<span><i class="swatch" style="background:#b6c5c5"></i>Typical</span></span></header>' +
          UI.chartBox('bench', 280) +
          '<p class="hint">Anything above the grey bar is where your household differs most from a ' +
          'similar home, and where a change is worth the effort.</p>' +
        '</section>' +

        '<p class="notice"><b>Read this carefully.</b> ' + UI.esc(d.note) + ' Install smart plugs if you ' +
        'need per-device truth rather than a model.</p>';

      SEChart.render(document.getElementById('donut'), {
        type: 'donut', height: 240, slices: slices,
        centerValue: UI.num(d.total_kwh, 0), centerLabel: 'kWh in 30 days'
      });

      SEChart.render(document.getElementById('bench'), {
        type: 'bar', height: 280, rotate: true,
        labels: d.appliances.map(function (a) { return a.name; }),
        series: [
          { type: 'bar', values: d.appliances.map(function (a) { return a.benchmark_monthly_kwh; }),
            color: '#b6c5c5' },
          { type: 'bar', values: d.appliances.map(function (a) { return a.monthly_kwh; }),
            color: '#e8871e', opacity: .9,
            flags: d.appliances.map(function (a) { return a.vs_benchmark > 1.25; }), flagColor: '#c0392b' }
        ]
      });
    }
  };

  // ======================================================================= BILL

  function slabRows(slabs) {
    return slabs.map(function (slab, i) {
      return '<tr data-slab="' + i + '">' +
        '<td><input type="number" class="slab-upto" value="' + (slab.upto === null ? '' : slab.upto) +
          '" placeholder="no limit" style="width:120px"></td>' +
        '<td><input type="number" step="0.01" class="slab-rate" value="' + slab.rate +
          '" style="width:100px"></td>' +
        '<td><button class="btn slab-remove" type="button">Remove</button></td></tr>';
    }).join('');
  }

  var bill = {
    title: 'Bill estimator',
    sub: function () { return 'Change any assumption and the estimate recalculates'; },
    load: function () {
      return Promise.all([API.settings(), API.overview('month')]).then(function (r) {
        return { settings: r[0], overview: r[1] };
      });
    },
    render: function (root, d, state) {
      var tariff = d.settings.tariff;
      UI.setCurrency(tariff.currency_symbol);
      var startKwh = state.billKwh || Math.round(d.overview.totals.projected_month_kwh);

      root.innerHTML =
        '<section class="grid split">' +
          '<div class="card">' +
            '<header><h2>What you are billed for</h2></header>' +
            '<div class="grid cols-2">' +
              '<div class="field"><label for="kwh">Units consumed (kWh)</label>' +
                '<input type="number" id="kwh" min="0" step="0.1" value="' + startKwh + '">' +
                '<span class="help">Prefilled with this month\'s projection</span></div>' +
              '<div class="field"><label for="days">Billing period (days)</label>' +
                '<input type="number" id="days" min="1" max="120" value="' + tariff.billing_days + '">' +
                '<span class="help">Slab limits scale with the period</span></div>' +
              '<div class="field"><label for="fixed">Fixed charge (' + UI.esc(tariff.currency_symbol) + ')</label>' +
                '<input type="number" id="fixed" min="0" step="1" value="' + tariff.fixed_charge + '"></div>' +
              '<div class="field"><label for="duty">Duty / tax (%)</label>' +
                '<input type="number" id="duty" min="0" max="50" step="0.1" value="' + tariff.duty_percent + '"></div>' +
            '</div>' +
            '<h3 style="margin:16px 0 6px">Tariff slabs</h3>' +
            '<p class="hint">Leave the last limit blank so it covers everything above the slab before it. ' +
            'Copy the numbers from your own electricity bill for a realistic estimate.</p>' +
            '<div class="table-wrap"><table><thead><tr><th>Up to (units)</th><th>Rate per unit</th><th></th></tr></thead>' +
            '<tbody id="slab-body">' + slabRows(tariff.slabs) + '</tbody></table></div>' +
            '<div class="controls" style="margin-top:12px">' +
              '<button class="btn" id="add-slab" type="button">Add slab</button>' +
              '<button class="btn primary" id="calc" type="button">Calculate estimate</button>' +
              '<button class="btn" id="save-tariff" type="button">Save as my tariff</button>' +
            '</div>' +
          '</div>' +
          '<div class="card" id="result"><p class="empty">Enter your numbers and calculate.</p></div>' +
        '</section>' +
        '<p class="notice"><b>This is an estimate.</b> Real bills include provider-specific charges, ' +
        'subsidies, meter rent and rounding rules that vary by state and connection type.</p>';

      function readSlabs() {
        return Array.prototype.map.call(document.querySelectorAll('#slab-body tr'), function (row) {
          var upto = row.querySelector('.slab-upto').value;
          return {
            upto: upto === '' ? null : Number(upto),
            rate: Number(row.querySelector('.slab-rate').value) || 0
          };
        });
      }

      function currentTariff() {
        return {
          slabs: readSlabs(),
          fixed_charge: Number(document.getElementById('fixed').value) || 0,
          duty_percent: Number(document.getElementById('duty').value) || 0
        };
      }

      function calculate() {
        var kwh = Number(document.getElementById('kwh').value);
        var days = Number(document.getElementById('days').value);
        state.billKwh = kwh;
        API.estimateBill({ kwh: kwh, days: days, tariff: currentTariff() }).then(function (r) {
          document.getElementById('result').innerHTML =
            '<header><h2>Estimated bill</h2><span class="spacer"></span>' +
            '<span class="badge warn">Estimate</span></header>' +
            '<div class="tile accent" style="border:0;padding:0 0 12px">' +
              '<span class="label">Total for ' + UI.num(r.kwh, 1) + ' kWh over ' + r.days + ' days</span>' +
              '<span class="value" style="font-size:2.1rem">' + UI.money(r.total, 2) + '</span>' +
              '<span class="foot">Works out to ' + UI.money(r.effective_rate, 2) + ' per unit</span></div>' +
            UI.table(['Slab', 'Units', 'Rate', 'Amount'], r.lines.map(function (l) {
              return [UI.esc(l.slab), UI.num(l.units, 1), UI.money(l.rate, 2), UI.money(l.amount, 2)];
            })) +
            '<table style="margin-top:10px"><tbody>' +
              '<tr><td>Energy charge</td><td>' + UI.money(r.energy_charge, 2) + '</td></tr>' +
              '<tr><td>Fixed charge</td><td>' + UI.money(r.fixed_charge, 2) + '</td></tr>' +
              '<tr><td>Duty at ' + r.duty_percent + '%</td><td>' + UI.money(r.duty, 2) + '</td></tr>' +
              '</tbody><tfoot><tr><td>Estimated total</td><td>' + UI.money(r.total, 2) + '</td></tr></tfoot></table>' +
            '<p class="hint" style="margin-top:12px">Carbon for this consumption: about ' +
              UI.num(r.co2_kg, 1) + ' kg CO\u2082. ' + UI.esc(r.disclaimer) + '</p>';
        }).catch(function (err) {
          document.getElementById('result').innerHTML = '<div class="error">' + UI.esc(err.message) + '</div>';
        });
      }

      document.getElementById('calc').addEventListener('click', calculate);
      document.getElementById('add-slab').addEventListener('click', function () {
        var body = document.getElementById('slab-body');
        body.insertAdjacentHTML('beforeend', slabRows([{ upto: null, rate: 8.5 }]));
      });
      document.getElementById('slab-body').addEventListener('click', function (e) {
        if (e.target.classList.contains('slab-remove')) e.target.closest('tr').remove();
      });
      document.getElementById('save-tariff').addEventListener('click', function () {
        var settings = d.settings;
        settings.tariff = Object.assign({}, settings.tariff, currentTariff(), {
          billing_days: Number(document.getElementById('days').value) || 30
        });
        API.saveSettings(settings).then(function () {
          UI.toast('Tariff saved. Every page now uses it.');
        }).catch(function (err) { UI.toast(err.message); });
      });
      calculate();
    }
  };

  // ==================================================================== SAVINGS

  var savings = {
    title: 'Energy-saving recommendations',
    sub: function (d) {
      return d.recommendations.length + ' ideas worth about ' + UI.money(d.totals.cost_year) + ' a year';
    },
    load: function () { return API.recommendations(); },
    render: function (root, d) {
      root.innerHTML =
        '<section class="grid cols-4">' +
          UI.tile({ label: 'Monthly saving available', value: UI.money(d.totals.cost_month),
                    accent: 'accent-teal', foot: 'If you act on everything below' }) +
          UI.tile({ label: 'Over a year', value: UI.money(d.totals.cost_year),
                    foot: 'At today\'s tariff' }) +
          UI.tile({ label: 'Energy avoided', value: UI.num(d.totals.kwh_month, 0), unit: 'kWh',
                    foot: 'Per month' }) +
          UI.tile({ label: 'CO\u2082 avoided', value: UI.num(d.totals.co2_kg_year, 0), unit: 'kg',
                    accent: 'accent-teal', foot: 'Per year' }) +
        '</section>' +

        '<section class="card">' +
          '<header><h2>Ranked by what it saves you</h2><span class="spacer"></span>' +
          '<span class="hint">Start at the top</span></header>' +
          d.recommendations.map(function (r) {
            return '<div class="entry sev-info">' +
              '<i class="rail" style="background:' + (r.rank <= 3 ? '#0f766e' : '#b6c5c5') + '"></i>' +
              '<div class="body">' +
                '<h3><span class="rank"><span class="n' + (r.rank === 1 ? ' top' : '') + '">' + r.rank +
                  '</span>' + UI.esc(r.title) + '</span></h3>' +
                '<p>' + UI.esc(r.detail) + '</p>' +
                '<div class="legend"><span class="badge">' + UI.esc(r.appliance) + '</span>' +
                  '<span class="badge">' + UI.esc(r.difficulty) + '</span>' +
                  '<span class="badge">' + UI.esc(r.effort) + '</span>' +
                  '<span class="badge">Cost to do: ' + UI.esc(r.cost_to_do) + '</span></div>' +
              '</div>' +
              '<div class="money"><span class="amt">' + UI.money(r.saving_cost_month) +
                '</span><span class="cap">a month \u00b7 ' + UI.num(r.saving_kwh_month, 1) + ' kWh</span>' +
                '<span class="cap">' + UI.num(r.co2_saved_kg_year, 0) + ' kg CO\u2082 a year</span></div></div>';
          }).join('') +
        '</section>' +

        '<section class="card"><header><h2>Where the savings sit</h2></header>' +
          UI.chartBox('save-chart', 260) + '</section>' +

        '<p class="notice">' + UI.esc(d.note) + '</p>';

      SEChart.render(document.getElementById('save-chart'), {
        type: 'bar', height: 260, rotate: true, unit: ' kWh',
        labels: d.recommendations.map(function (r) { return r.appliance; }),
        tipLabels: d.recommendations.map(function (r) { return r.title; }),
        series: [{ type: 'bar', values: d.recommendations.map(function (r) { return r.saving_kwh_month; }),
                   color: '#0f766e' }]
      });
    }
  };

  // ==================================================================== REPORTS

  var reports = {
    title: 'Reports',
    sub: function (d) { return d.period.start + ' to ' + d.period.end + ' \u00b7 ' + d.period.days + ' days'; },
    controls: function (state) {
      return UI.segmented('reportDays', [
        { value: '7', label: '7 days' },
        { value: '30', label: '30 days' },
        { value: '90', label: '90 days' }
      ], state.reportDays);
    },
    load: function (state) { return API.report(state.reportDays); },
    render: function (root, d) {
      UI.setCurrency(d.currency_symbol);
      root.innerHTML =
        '<section class="card">' +
          '<header><h2>Energy report</h2><span class="spacer"></span>' +
            '<button class="btn no-print" id="print-btn">Print or save as PDF</button>' +
            '<a class="btn no-print" href="/api/export/consumption.csv?days=' + d.period.days + '">Daily CSV</a>' +
            '<a class="btn no-print" href="/api/export/hourly.csv?days=14">Hourly CSV</a>' +
          '</header>' +
          '<p>' + UI.esc(d.household.name) + ' \u00b7 ' + UI.esc(d.household.home_type) + ' \u00b7 ' +
            d.household.occupants + ' occupants \u00b7 ' + UI.esc(d.household.city) + '<br>' +
            '<span class="hint">Covering ' + UI.fullDate(d.period.start) + ' to ' + UI.fullDate(d.period.end) +
            ', generated ' + new Date(d.generated_at).toLocaleString() + '.</span></p>' +
          '<div class="grid cols-4" style="margin-top:6px">' +
            UI.tile({ label: 'Total consumption', value: UI.num(d.totals.kwh, 1), unit: 'kWh', accent: 'accent' }) +
            UI.tile({ label: 'Estimated cost', value: UI.money(d.bill.total) }) +
            UI.tile({ label: 'Daily average', value: UI.num(d.totals.avg_daily_kwh, 2), unit: 'kWh' }) +
            UI.tile({ label: 'CO\u2082', value: UI.num(d.totals.co2_kg, 0), unit: 'kg', accent: 'accent-teal' }) +
          '</div>' +
        '</section>' +

        '<section class="card"><header><h2>Consumption over the period</h2></header>' +
          UI.chartBox('report-chart', 260) + '</section>' +

        '<section class="grid cols-2">' +
          '<div class="card"><header><h2>Appliance breakdown</h2></header>' +
            UI.table(['Appliance', 'kWh / month', 'Share', 'Est. cost'],
              d.appliances.map(function (a) {
                return [UI.esc(a.name), UI.num(a.monthly_kwh, 1), a.share_percent + '%',
                        UI.money(a.monthly_cost)];
              })) + '</div>' +
          '<div class="card"><header><h2>Bill breakdown</h2></header>' +
            '<table><tbody>' +
              '<tr><td>Energy charge</td><td>' + UI.money(d.bill.energy_charge, 2) + '</td></tr>' +
              '<tr><td>Fixed charge</td><td>' + UI.money(d.bill.fixed_charge, 2) + '</td></tr>' +
              '<tr><td>Duty at ' + d.bill.duty_percent + '%</td><td>' + UI.money(d.bill.duty, 2) + '</td></tr>' +
            '</tbody><tfoot><tr><td>Estimated total</td><td>' + UI.money(d.bill.total, 2) + '</td></tr></tfoot></table>' +
            '<p class="hint" style="margin-top:12px">Efficiency score ' + d.efficiency.score + '/100 (' +
              UI.esc(d.efficiency.band) + ').</p>' +
          '</div>' +
        '</section>' +

        '<section class="card"><header><h2>Findings</h2></header>' +
          d.insights.map(function (i) {
            return '<div class="entry ' + severityClass(i.severity) + '"><i class="rail"></i>' +
              '<div class="body"><h3>' + UI.esc(i.title) + '</h3><p>' + UI.esc(i.explanation) + '</p></div>' +
              '<div class="money"><span class="amt">' + (i.saving_cost ? UI.money(i.saving_cost) : '\u2014') +
              '</span><span class="cap">a month</span></div></div>';
          }).join('') + '</section>' +

        '<section class="grid cols-2">' +
          '<div class="card"><header><h2>Anomalies in this period</h2></header>' +
            '<p>' + d.anomalies.events + ' events, ' + d.anomalies.high + ' of them high severity, ' +
            'totalling ' + UI.num(d.anomalies.excess_kwh, 1) + ' kWh of unexpected energy.</p>' +
            UI.table(['When', 'Severity', 'Excess'], d.top_anomalies.map(function (e) {
              return [UI.esc(e.window) + '<br><span class="hint">' + UI.esc(e.date) + '</span>',
                      UI.severityBadge(e.severity), '+' + UI.num(e.excess_kwh, 2) + ' kWh'];
            })) + '</div>' +
          '<div class="card"><header><h2>Recommended actions</h2></header>' +
            UI.table(['Action', 'Saving / month'], d.recommendations.map(function (r) {
              return [UI.esc(r.title), UI.money(r.saving_cost_month)];
            })) + '</div>' +
        '</section>' +

        '<p class="notice"><b>Demo data.</b> This report is generated from sample readings so the ' +
        'format can be reviewed end to end. Figures are estimates.</p>';

      SEChart.render(document.getElementById('report-chart'), {
        type: 'area', height: 260,
        labels: d.daily.map(function (r) { return UI.dayLabel(r.date); }),
        tipLabels: d.daily.map(function (r) { return UI.fullDate(r.date); }),
        series: [{ values: d.daily.map(function (r) { return r.kwh; }), color: '#e8871e', fill: true, width: 2 }]
      });

      document.getElementById('print-btn').addEventListener('click', function () { window.print(); });
    }
  };

  // =================================================================== SETTINGS

  var settings = {
    title: 'Settings',
    sub: function () { return 'Assumptions used across every page'; },
    load: function () { return Promise.all([API.settings(), API.health()]).then(function (r) {
      return { settings: r[0], health: r[1] };
    }); },
    render: function (root, d) {
      var s = d.settings;
      var ai = d.health.ai;

      root.innerHTML =
        '<section class="grid cols-2">' +
          '<div class="card"><header><h2>Household</h2></header>' +
            '<div class="grid cols-2">' +
              '<div class="field"><label for="hh-name">Name</label><input id="hh-name" value="' + UI.esc(s.household.name) + '"></div>' +
              '<div class="field"><label for="hh-type">Home type</label><input id="hh-type" value="' + UI.esc(s.household.home_type) + '"></div>' +
              '<div class="field"><label for="hh-people">Occupants</label><input id="hh-people" type="number" min="1" max="20" value="' + s.household.occupants + '"></div>' +
              '<div class="field"><label for="hh-city">City</label><input id="hh-city" value="' + UI.esc(s.household.city) + '"></div>' +
            '</div>' +
            '<p class="hint">Occupants feed the per-person part of the efficiency score.</p>' +
          '</div>' +

          '<div class="card"><header><h2>Targets and environment</h2></header>' +
            '<div class="grid cols-2">' +
              '<div class="field"><label for="t-month">Monthly target (kWh)</label><input id="t-month" type="number" min="0" value="' + s.targets.monthly_kwh_target + '"></div>' +
              '<div class="field"><label for="t-base">Baseline kWh per person per day</label><input id="t-base" type="number" step="0.1" min="0.5" value="' + s.targets.efficiency_baseline_kwh_per_person_day + '"></div>' +
              '<div class="field"><label for="e-co2">CO\u2082 per kWh (kg)</label><input id="e-co2" type="number" step="0.01" min="0" value="' + s.environment.co2_factor + '"><span class="help">India grid average is roughly 0.7\u20130.85</span></div>' +
              '<div class="field"><label for="t-peak">Peak hours</label><input id="t-peak" value="' + s.targets.peak_hours.join(', ') + '"><span class="help">Hours of the day, 0\u201323</span></div>' +
            '</div>' +
          '</div>' +
        '</section>' +

        '<section class="card"><header><h2>Tariff</h2><span class="spacer"></span>' +
          '<span class="hint">Used by every cost figure in the app</span></header>' +
          '<div class="grid cols-3">' +
            '<div class="field"><label for="cur">Currency symbol</label><input id="cur" value="' + UI.esc(s.tariff.currency_symbol) + '"></div>' +
            '<div class="field"><label for="fixedc">Fixed charge</label><input id="fixedc" type="number" step="1" min="0" value="' + s.tariff.fixed_charge + '"></div>' +
            '<div class="field"><label for="dutyp">Duty / tax (%)</label><input id="dutyp" type="number" step="0.1" min="0" value="' + s.tariff.duty_percent + '"></div>' +
          '</div>' +
          '<p class="hint" style="margin-top:12px">Edit slabs on the ' +
          '<a href="#/bill">Bill estimator</a>, where you can test them against a consumption figure first.</p>' +
          UI.table(['Up to (units)', 'Rate per unit'], s.tariff.slabs.map(function (slab) {
            return [slab.upto === null ? 'Above the previous slab' : UI.num(slab.upto, 0),
                    UI.money(slab.rate, 2)];
          })) +
        '</section>' +

        '<section class="grid cols-2">' +
          '<div class="card"><header><h2>Demo data</h2></header>' +
            '<p>The app ships with a generated household so every screen is populated on first run. ' +
            'Currently holding <b>' + d.health.hourly_readings.toLocaleString() + '</b> hourly readings ' +
            'across ' + s.demo.days_of_history + ' days.</p>' +
            '<div class="field" style="max-width:220px"><label for="hist">Days of history</label>' +
              '<input id="hist" type="number" min="30" max="730" value="' + s.demo.days_of_history + '"></div>' +
            '<div class="controls" style="margin-top:12px">' +
              '<button class="btn" id="regen">Generate a different household</button>' +
              '<button class="btn" id="reset">Reset everything to defaults</button></div>' +
          '</div>' +

          '<div class="card"><header><h2>AI provider</h2><span class="spacer"></span>' +
            '<span class="badge ' + (ai.enabled ? 'ok' : '') + '">' + (ai.enabled ? 'Connected' : 'Offline') + '</span></header>' +
            '<p>' + UI.esc(ai.message) + '</p>' +
            '<p class="hint">The API key, if you use one, is read by the server from <code>.env</code> and ' +
            'never sent to this page. Ollama is the free option and runs on your own machine. ' +
            'Everything except the written narrative works with no provider at all.</p>' +
            '<p class="hint">Server version ' + UI.esc(d.health.version) + ' \u00b7 mode ' + UI.esc(d.health.mode) + '</p>' +
          '</div>' +
        '</section>' +

        '<div class="controls"><button class="btn primary" id="save">Save settings</button>' +
        '<span class="hint" id="save-hint">Changes apply immediately across the app.</span></div>';

      document.getElementById('save').addEventListener('click', function () {
        var peak = document.getElementById('t-peak').value.split(',')
          .map(function (v) { return parseInt(v.trim(), 10); })
          .filter(function (v) { return !isNaN(v) && v >= 0 && v <= 23; });
        var payload = {
          household: {
            name: document.getElementById('hh-name').value,
            home_type: document.getElementById('hh-type').value,
            occupants: Number(document.getElementById('hh-people').value) || 1,
            city: document.getElementById('hh-city').value
          },
          tariff: Object.assign({}, s.tariff, {
            currency_symbol: document.getElementById('cur').value || '\u20b9',
            fixed_charge: Number(document.getElementById('fixedc').value) || 0,
            duty_percent: Number(document.getElementById('dutyp').value) || 0
          }),
          targets: Object.assign({}, s.targets, {
            monthly_kwh_target: Number(document.getElementById('t-month').value) || 0,
            efficiency_baseline_kwh_per_person_day: Number(document.getElementById('t-base').value) || 3.2,
            peak_hours: peak.length ? peak : s.targets.peak_hours
          }),
          environment: Object.assign({}, s.environment, {
            co2_factor: Number(document.getElementById('e-co2').value) || 0.82
          }),
          demo: Object.assign({}, s.demo, {
            days_of_history: Number(document.getElementById('hist').value) || 180
          })
        };
        API.saveSettings(payload).then(function () {
          UI.toast('Settings saved.');
          global.App.reload();
        }).catch(function (err) { UI.toast(err.message); });
      });

      document.getElementById('regen').addEventListener('click', function () {
        API.regenerate().then(function (r) {
          UI.toast('New household generated from seed ' + r.seed + '.');
          global.App.reload();
        }).catch(function (err) { UI.toast(err.message); });
      });

      document.getElementById('reset').addEventListener('click', function () {
        API.resetSettings().then(function () {
          UI.toast('Settings reset.');
          global.App.reload();
        }).catch(function (err) { UI.toast(err.message); });
      });
    }
  };

  global.Pages = {
    dashboard: dashboard, consumption: consumption, insights: insights,
    prediction: prediction, anomalies: anomalies, appliances: appliances,
    bill: bill, savings: savings, reports: reports, settings: settings
  };
})(window);
