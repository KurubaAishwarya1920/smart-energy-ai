"""Tests for Smart Energy AI.

Uses only the standard library:  python -m unittest discover tests
"""

import datetime as dt
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend import analytics, config, data_store, insights, ml  # noqa: E402
from backend.app import create_app  # noqa: E402


class DataTests(unittest.TestCase):
    def setUp(self):
        self.settings = config.DEFAULT_SETTINGS
        self.readings = data_store.generate_readings(seed=42, days=90)

    def test_generation_is_deterministic(self):
        again = data_store.generate_readings(seed=42, days=90)
        self.assertEqual(len(self.readings), len(again))
        self.assertEqual(self.readings[100]["total"], again[100]["total"])

    def test_every_reading_is_positive_and_adds_up(self):
        for reading in self.readings[:500]:
            self.assertGreater(reading["total"], 0)
            self.assertAlmostEqual(
                reading["total"], sum(reading["appliances"].values()), places=3)

    def test_daily_series_covers_every_day(self):
        rows = analytics.daily_series(self.readings)
        self.assertEqual(len(rows), 91)  # 90 days of history plus today
        self.assertTrue(all(row["kwh"] > 0 for row in rows))

    def test_household_consumption_is_realistic(self):
        rows = [r for r in analytics.daily_series(self.readings) if r["hours_recorded"] >= 24]
        average = sum(r["kwh"] for r in rows) / len(rows)
        self.assertTrue(6 < average < 20, "daily average out of range: %s" % average)


class BillTests(unittest.TestCase):
    def setUp(self):
        self.settings = config.DEFAULT_SETTINGS

    def test_slabs_are_cumulative(self):
        bill = analytics.estimate_bill(120, self.settings, 30)
        units = sum(line["units"] for line in bill["lines"])
        self.assertAlmostEqual(units, 120, places=2)
        # 50 at 3.50 + 50 at 4.50 + 20 at 6.00
        self.assertAlmostEqual(bill["energy_charge"], 175 + 225 + 120, places=2)

    def test_total_includes_fixed_charge_and_duty(self):
        bill = analytics.estimate_bill(100, self.settings, 30)
        expected = (bill["energy_charge"] + bill["fixed_charge"]) * 1.06
        self.assertAlmostEqual(bill["total"], round(expected, 2), places=1)

    def test_zero_consumption_still_bills_the_fixed_charge(self):
        bill = analytics.estimate_bill(0, self.settings, 30)
        self.assertEqual(bill["lines"], [])
        self.assertGreater(bill["total"], 0)

    def test_more_units_never_costs_less(self):
        previous = 0
        for kwh in range(0, 600, 50):
            total = analytics.estimate_bill(kwh, self.settings, 30)["total"]
            self.assertGreaterEqual(total, previous)
            previous = total


class IntelligenceTests(unittest.TestCase):
    def setUp(self):
        self.settings = config.DEFAULT_SETTINGS
        self.readings = data_store.generate_readings(seed=7, days=150)

    def test_forecast_is_in_a_sensible_range(self):
        result = ml.forecast(self.readings, self.settings)
        rows = [r for r in analytics.daily_series(self.readings) if r["hours_recorded"] >= 24]
        average = sum(r["kwh"] for r in rows[-30:]) / 30
        self.assertTrue(0.5 * average < result["next_day"]["kwh"] < 1.8 * average)
        self.assertLessEqual(result["next_day"]["low"], result["next_day"]["kwh"])
        self.assertGreaterEqual(result["next_day"]["high"], result["next_day"]["kwh"])
        self.assertTrue(35 <= result["confidence_percent"] <= 95)
        self.assertEqual(len(result["next_week"]["days"]), 7)

    def test_injected_faults_are_detected(self):
        found = ml.detect_anomalies(self.readings, self.settings)
        self.assertGreaterEqual(found["summary"]["events"], 3)
        today = dt.date.today()
        expected = {(today - dt.timedelta(days=e["days_ago"])).isoformat()
                    for e in data_store.ANOMALY_SCRIPT}
        detected = {e["date"] for e in found["events"]}
        self.assertTrue(expected & detected, "no scripted fault was detected")

    def test_a_calm_household_produces_few_anomalies(self):
        quiet = [r for r in self.readings]
        for reading in quiet:
            reading.pop("anomaly_hint", None)
        found = ml.detect_anomalies(quiet, self.settings)
        self.assertLess(found["summary"]["events"], found["summary"]["days_analysed"] * 0.2)

    def test_insights_are_actionable(self):
        payload = insights.build_insights(self.readings, self.settings)
        self.assertGreaterEqual(len(payload["insights"]), 4)
        for item in payload["insights"]:
            self.assertTrue(item["title"] and item["explanation"] and item["action"])
            self.assertIn(item["severity"], {"critical", "warning", "info"})

    def test_recommendations_are_ranked_by_value(self):
        payload = insights.build_recommendations(self.readings, self.settings)
        values = [r["saving_cost_month"] for r in payload["recommendations"]]
        self.assertEqual(values, sorted(values, reverse=True))

    def test_appliance_shares_add_up(self):
        rows = analytics.appliance_breakdown(self.readings, self.settings)
        self.assertAlmostEqual(sum(r["share_percent"] for r in rows), 100, delta=0.5)
        self.assertEqual(rows[0]["rank"], 1)


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = create_app().test_client()

    def test_every_endpoint_answers(self):
        paths = [
            "/api/health", "/api/overview?range=week", "/api/consumption?view=weekly",
            "/api/appliances", "/api/insights", "/api/predictions", "/api/anomalies",
            "/api/recommendations", "/api/reports/summary", "/api/settings",
            "/api/export/consumption.csv",
        ]
        for path in paths:
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code, 200)

    def test_the_page_itself_is_served(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Smart Energy AI", response.data)

    def test_bill_endpoint_rejects_nonsense(self):
        self.assertEqual(self.client.post("/api/bill/estimate",
                                          json={"kwh": -5, "days": 30}).status_code, 400)
        self.assertEqual(self.client.post("/api/bill/estimate",
                                          json={"kwh": "abc", "days": 30}).status_code, 400)

    def test_ai_status_never_leaks_a_key(self):
        os.environ["AI_PROVIDER"] = "openai"
        os.environ["OPENAI_API_KEY"] = "test-key-should-never-appear"
        try:
            body = self.client.get("/api/health").data.decode("utf-8")
            self.assertNotIn("test-key-should-never-appear", body)
        finally:
            os.environ.pop("AI_PROVIDER", None)
            os.environ.pop("OPENAI_API_KEY", None)

    def test_unknown_api_path_returns_json_404(self):
        response = self.client.get("/api/does-not-exist")
        self.assertEqual(response.status_code, 404)
        self.assertIn("error", response.get_json())


if __name__ == "__main__":
    unittest.main(verbosity=2)
