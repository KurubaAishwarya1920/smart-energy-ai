"""Demo data generation for Smart Energy AI.

Everything here is SYNTHETIC. It is generated from a fixed seed so the app looks
identical on every run and every machine, which matters for a live demo.

Structure produced:
    readings = [
        {"ts": datetime, "hour": int, "date": "YYYY-MM-DD",
         "appliances": {name: kWh, ...}, "total": kWh},
        ...
    ]
one entry per hour, for `days_of_history` days ending yesterday, plus the
elapsed hours of today.
"""

import datetime as dt
import math
import random
import threading

# name -> profile
# base_kwh   : kWh drawn in an hour when the appliance is fully on
# duty       : 24 hourly duty factors (0..1), how much of that hour it runs
# weekend    : multiplier on weekends
# seasonal   : how strongly it reacts to the hot-season curve (0 = not at all)
# standby    : always-on floor in kWh/hour
APPLIANCE_PROFILES = {
    "Air Conditioner": {
        "base_kwh": 1.45,
        "duty": [0.196, 0.196, 0.183, 0.144, 0.065, 0.013,
                 0, 0, 0, 0, 0.013, 0.039,
                 0.078, 0.104, 0.117, 0.104, 0.078, 0.065,
                 0.091, 0.144, 0.183, 0.222, 0.222, 0.209],
        "weekend": 1.18, "seasonal": 1.0, "standby": 0.0,
        "category": "Cooling", "rated_w": 1450,
    },
    "Refrigerator": {
        "base_kwh": 0.16,
        "duty": [0.318, 0.318, 0.318, 0.318, 0.318, 0.318,
                 0.376, 0.433, 0.462, 0.433, 0.405, 0.433,
                 0.462, 0.433, 0.405, 0.405, 0.433, 0.462,
                 0.491, 0.491, 0.462, 0.433, 0.376, 0.347],
        "weekend": 1.05, "seasonal": 0.35, "standby": 0.0116,
        "category": "Always on", "rated_w": 160,
    },
    "Washing Machine": {
        "base_kwh": 0.7,
        "duty": [0, 0, 0, 0, 0, 0,
                 0.023, 0.103, 0.126, 0.08, 0.034, 0.011,
                 0, 0, 0, 0, 0, 0.011,
                 0.023, 0.011, 0, 0, 0, 0],
        "weekend": 1.9, "seasonal": 0.0, "standby": 0.0009,
        "category": "Laundry", "rated_w": 700,
    },
    "Television": {
        "base_kwh": 0.12,
        "duty": [0, 0, 0, 0, 0, 0,
                 0.029, 0.117, 0.146, 0.088, 0.058, 0.058,
                 0.088, 0.117, 0.088, 0.117, 0.205, 0.322,
                 0.439, 0.526, 0.556, 0.468, 0.234, 0.058],
        "weekend": 1.35, "seasonal": 0.0, "standby": 0.0047,
        "category": "Entertainment", "rated_w": 120,
    },
    "Lights": {
        "base_kwh": 0.22,
        "duty": [0.059, 0.047, 0.047, 0.059, 0.148, 0.208,
                 0.178, 0.119, 0.059, 0.03, 0.03, 0.03,
                 0.03, 0.03, 0.03, 0.059, 0.148, 0.356,
                 0.534, 0.563, 0.534, 0.445, 0.267, 0.119],
        "weekend": 1.05, "seasonal": 0.0, "standby": 0.0,
        "category": "Lighting", "rated_w": 220,
    },
    "Fan": {
        "base_kwh": 0.075,
        "duty": [0.717, 0.717, 0.717, 0.674, 0.506, 0.295,
                 0.211, 0.253, 0.295, 0.337, 0.421, 0.506,
                 0.59, 0.632, 0.632, 0.59, 0.548, 0.59,
                 0.674, 0.717, 0.759, 0.759, 0.759, 0.742],
        "weekend": 1.05, "seasonal": 0.8, "standby": 0.0,
        "category": "Cooling", "rated_w": 75,
    },
    "Water Heater": {
        "base_kwh": 2.0,
        "duty": [0, 0, 0, 0, 0.01, 0.068,
                 0.117, 0.107, 0.058, 0.02, 0, 0,
                 0, 0, 0, 0, 0, 0,
                 0.01, 0.029, 0.039, 0.029, 0.01, 0],
        "weekend": 1.15, "seasonal": -0.9, "standby": 0.0,
        "category": "Heating", "rated_w": 2000,
    },
    "Laptop": {
        "base_kwh": 0.065,
        "duty": [0.032, 0.013, 0.013, 0.013, 0.013, 0.032,
                 0.096, 0.192, 0.352, 0.512, 0.544, 0.544,
                 0.448, 0.512, 0.544, 0.544, 0.48, 0.352,
                 0.288, 0.32, 0.384, 0.352, 0.192, 0.064],
        "weekend": 0.65, "seasonal": 0.0, "standby": 0.0038,
        "category": "Work", "rated_w": 65,
    },
    "Other": {
        "base_kwh": 0.14,
        "duty": [0.145, 0.116, 0.116, 0.116, 0.145, 0.232,
                 0.319, 0.348, 0.319, 0.261, 0.232, 0.261,
                 0.29, 0.261, 0.232, 0.232, 0.29, 0.348,
                 0.406, 0.435, 0.406, 0.348, 0.261, 0.174],
        "weekend": 1.1, "seasonal": 0.1, "standby": 0.0087,
        "category": "Mixed", "rated_w": 140,
    },
}

APPLIANCE_NAMES = list(APPLIANCE_PROFILES.keys())

# Anomalies are injected deliberately so Anomaly Detection has something real to
# find during a demo. days_ago is counted back from today.
# extra_kwh is added to that appliance for each listed hour, which is how a real
# fault looks on a meter: a roughly constant extra draw for a stretch of hours.
ANOMALY_SCRIPT = [
    {"days_ago": 3, "appliance": "Air Conditioner", "hours": list(range(0, 7)),
     "extra_kwh": 1.05,
     "reason": "Air conditioner ran through the night at a low set point instead of cycling off."},
    {"days_ago": 6, "appliance": "Water Heater", "hours": [19, 20, 21],
     "extra_kwh": 1.70,
     "reason": "Water heater drew power continuously in the evening - the thermostat may not be cutting off."},
    {"days_ago": 11, "appliance": "Other", "hours": [13, 14, 15, 16],
     "extra_kwh": 1.20,
     "reason": "A large unidentified load ran right through the afternoon."},
    {"days_ago": 18, "appliance": "Washing Machine", "hours": [20, 21, 22],
     "extra_kwh": 0.95,
     "reason": "Several wash cycles ran back to back during peak hours."},
    {"days_ago": 27, "appliance": "Air Conditioner", "hours": [11, 12, 13, 14, 15],
     "extra_kwh": 0.95,
     "reason": "Cooling load stayed high through the afternoon while the home was likely empty."},
    {"days_ago": 41, "appliance": "Refrigerator", "hours": list(range(0, 24)),
     "extra_kwh": 0.22,
     "reason": "Refrigerator ran almost continuously for a full day - door seal or overload suspected."},
]

_cache = {"key": None, "readings": None}
_lock = threading.Lock()


def _season_factor(day_of_year):
    """Hot-season curve, peaking around late May (day ~145) in southern India."""
    return math.sin(2 * math.pi * (day_of_year - 55) / 365.0)


def generate_readings(seed=20260918, days=180, today=None):
    """Build hourly readings for `days` days of history plus today so far."""
    rng = random.Random(seed)
    today = today or dt.date.today()
    now_hour = dt.datetime.now().hour
    start = today - dt.timedelta(days=days)

    readings = []
    day_count = days + 1
    for offset in range(day_count):
        day = start + dt.timedelta(days=offset)
        is_today = day == today
        is_weekend = day.weekday() >= 5
        season = _season_factor(day.timetuple().tm_yday)
        # Slow upward drift in usage across the history window (~7% over 180 days).
        drift = 1.0 + 0.07 * (offset / max(day_count - 1, 1))
        day_mood = rng.uniform(0.92, 1.08)  # household varies day to day

        hours = range(24) if not is_today else range(now_hour + 1)
        for hour in hours:
            per_appliance = {}
            for name, prof in APPLIANCE_PROFILES.items():
                duty = prof["duty"][hour]
                value = prof["base_kwh"] * duty
                if prof["weekend"] != 1.0 and is_weekend:
                    value *= prof["weekend"]
                if prof["seasonal"]:
                    value *= max(0.15, 1.0 + prof["seasonal"] * 0.45 * season)
                value *= drift * day_mood
                value *= rng.uniform(0.85, 1.15)
                value += prof["standby"]
                per_appliance[name] = round(max(value, 0.0), 4)
            readings.append({
                "date": day.isoformat(),
                "hour": hour,
                "weekday": day.weekday(),
                "appliances": per_appliance,
                "total": round(sum(per_appliance.values()), 4),
            })

    _inject_anomalies(readings, today)
    return readings


def _inject_anomalies(readings, today):
    index = {(r["date"], r["hour"]): r for r in readings}
    for event in ANOMALY_SCRIPT:
        day = (today - dt.timedelta(days=event["days_ago"])).isoformat()
        for hour in event["hours"]:
            reading = index.get((day, hour))
            if not reading:
                continue
            name = event["appliance"]
            before = reading["appliances"][name]
            if "extra_kwh" in event:
                after = before + event["extra_kwh"]
            else:
                after = before * event.get("multiplier", 1.0)
            reading["appliances"][name] = round(after, 4)
            reading["total"] = round(sum(reading["appliances"].values()), 4)
            reading["anomaly_hint"] = event["reason"]


def get_readings(settings, force=False):
    """Cached accessor. Regenerates when seed/history length/date changes."""
    demo = settings.get("demo", {})
    key = (demo.get("seed"), demo.get("days_of_history"), dt.date.today().isoformat(),
           dt.datetime.now().hour)
    with _lock:
        if force or _cache["key"] != key or _cache["readings"] is None:
            _cache["readings"] = generate_readings(
                seed=int(demo.get("seed", 20260918)),
                days=int(demo.get("days_of_history", 180)),
            )
            _cache["key"] = key
        return _cache["readings"]


def invalidate():
    with _lock:
        _cache["key"] = None
        _cache["readings"] = None
