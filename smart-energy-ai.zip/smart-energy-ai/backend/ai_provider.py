"""OPTIONAL large-language-model narration.

The app is fully functional without any of this. If - and only if - the user
configures a provider in .env, the rule-based insights are additionally passed to
an LLM which writes a short plain-language summary and answers questions about
the data.

Rules this module follows:
  * API keys are read from the environment on the server. They are never sent to
    the browser and never written into any response.
  * No key is ever hard-coded. Absence of a key means offline mode, not an error.
  * Any failure (no network, bad key, timeout) degrades silently to the local
    summary so a demo can never break because the internet is down.

Supported, in priority order:
  AI_PROVIDER=ollama     free, runs locally, no key needed (http://localhost:11434)
  AI_PROVIDER=openai     any OpenAI-compatible endpoint via OPENAI_BASE_URL
  AI_PROVIDER=anthropic  Anthropic Messages API
"""

import json
import os
import urllib.error
import urllib.request

TIMEOUT = 25


def _env(name, default=None):
    value = os.environ.get(name)
    return value.strip() if value and value.strip() else default


def provider_name():
    return (_env("AI_PROVIDER") or "").lower()


def status():
    """Safe to expose to the frontend: says whether AI is on, never what the key is."""
    name = provider_name()
    if name == "ollama":
        return {"enabled": True, "provider": "ollama", "mode": "local",
                "model": _env("OLLAMA_MODEL", "llama3.2"),
                "message": "Using a local Ollama model. Nothing leaves this machine."}
    if name == "openai" and _env("OPENAI_API_KEY"):
        return {"enabled": True, "provider": "openai", "mode": "remote",
                "model": _env("OPENAI_MODEL", "gpt-4o-mini"),
                "message": "Using an OpenAI-compatible endpoint configured on the server."}
    if name == "anthropic" and _env("ANTHROPIC_API_KEY"):
        return {"enabled": True, "provider": "anthropic", "mode": "remote",
                "model": _env("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
                "message": "Using the Anthropic Messages API configured on the server."}
    return {"enabled": False, "provider": None, "mode": "offline", "model": None,
            "message": "Offline mode. Insights come from the built-in rule engine, which needs "
                       "no API key."}


SYSTEM_PROMPT = (
    "You are the analyst inside a home energy dashboard. You are given measured figures that "
    "have already been computed. Never invent numbers, never contradict the figures, and never "
    "claim certainty about the future. Write plain, specific prose for a homeowner: at most six "
    "sentences, no bullet points, no headings, no preamble."
)


def narrate(insight_payload, overview_payload):
    """Return a short narrative string, or None when AI is off or unreachable."""
    st = status()
    if not st["enabled"]:
        return None

    facts = {
        "month_kwh_projected": overview_payload["totals"]["projected_month_kwh"],
        "estimated_bill": overview_payload["bill"]["total"],
        "currency": overview_payload["currency_symbol"],
        "efficiency_score": overview_payload["efficiency"]["score"],
        "avg_daily_kwh": overview_payload["totals"]["avg_daily_kwh"],
        "co2_kg_month": overview_payload["totals"]["month_co2_kg"],
        "insights": [
            {"title": i["title"], "detail": i["explanation"],
             "possible_saving": i["saving_cost"]}
            for i in insight_payload["insights"][:6]
        ],
    }
    prompt = ("Here are this household's measured energy figures as JSON:\n"
              + json.dumps(facts, indent=2)
              + "\n\nWrite the summary the dashboard should show at the top of the page.")
    try:
        if st["provider"] == "ollama":
            return _ollama(prompt, st["model"])
        if st["provider"] == "openai":
            return _openai(prompt, st["model"])
        if st["provider"] == "anthropic":
            return _anthropic(prompt, st["model"])
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError,
            ValueError, KeyError):
        return None
    return None


def ask(question, context):
    st = status()
    if not st["enabled"]:
        return None
    prompt = ("Household energy data as JSON:\n" + json.dumps(context, indent=2)
              + "\n\nQuestion from the homeowner: " + question
              + "\n\nAnswer using only the figures above.")
    try:
        if st["provider"] == "ollama":
            return _ollama(prompt, st["model"])
        if st["provider"] == "openai":
            return _openai(prompt, st["model"])
        if st["provider"] == "anthropic":
            return _anthropic(prompt, st["model"])
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError,
            ValueError, KeyError):
        return None
    return None


def _post(url, payload, headers):
    request = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers}, method="POST")
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return json.loads(response.read().decode("utf-8"))


def _ollama(prompt, model):
    base = _env("OLLAMA_BASE_URL", "http://localhost:11434")
    data = _post(base.rstrip("/") + "/api/chat", {
        "model": model,
        "stream": False,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                     {"role": "user", "content": prompt}],
    }, {})
    return (data.get("message") or {}).get("content", "").strip() or None


def _openai(prompt, model):
    base = _env("OPENAI_BASE_URL", "https://api.openai.com/v1")
    key = _env("OPENAI_API_KEY")
    data = _post(base.rstrip("/") + "/chat/completions", {
        "model": model,
        "max_tokens": 400,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                     {"role": "user", "content": prompt}],
    }, {"Authorization": "Bearer " + key})
    return data["choices"][0]["message"]["content"].strip() or None


def _anthropic(prompt, model):
    key = _env("ANTHROPIC_API_KEY")
    data = _post("https://api.anthropic.com/v1/messages", {
        "model": model,
        "max_tokens": 400,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": prompt}],
    }, {"x-api-key": key, "anthropic-version": "2023-06-01"})
    parts = [block.get("text", "") for block in data.get("content", [])
             if block.get("type") == "text"]
    return "\n".join(parts).strip() or None
