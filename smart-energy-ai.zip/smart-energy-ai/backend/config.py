"""Configuration and user-editable settings for Smart Energy AI.

Settings live in data/settings.json so the user can change tariff assumptions
from the Settings page without touching code. Nothing here requires a paid API.
"""

import json
import os
import threading

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")

_lock = threading.Lock()

# Tariff slabs are ESTIMATES. They loosely follow a typical Indian domestic
# slab structure, but every board differs - the user is expected to edit them.
DEFAULT_SETTINGS = {
    "household": {
        "name": "Demo Household",
        "home_type": "2 BHK apartment",
        "occupants": 4,
        "city": "Visakhapatnam",
    },
    "tariff": {
        "currency": "INR",
        "currency_symbol": "\u20b9",
        "slabs": [
            {"upto": 50, "rate": 3.50},
            {"upto": 100, "rate": 4.50},
            {"upto": 200, "rate": 6.00},
            {"upto": 400, "rate": 7.50},
            {"upto": None, "rate": 8.50},
        ],
        "fixed_charge": 75.0,
        "duty_percent": 6.0,
        "billing_days": 30,
    },
    "environment": {
        # kg CO2 per kWh. India grid average is roughly 0.7-0.85; editable.
        "co2_factor": 0.82,
        "tree_offset_kg_per_year": 21.0,
    },
    "targets": {
        "monthly_kwh_target": 320.0,
        "peak_hours": [18, 19, 20, 21],
        "efficiency_baseline_kwh_per_person_day": 3.2,
    },
    "demo": {
        "seed": 20260918,
        "days_of_history": 180,
        "label": "Demo data",
    },
    "ui": {"theme": "light", "default_range": "month"},
}


def _deep_merge(base, override):
    out = dict(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_settings():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(SETTINGS_PATH):
        save_settings(DEFAULT_SETTINGS)
        return json.loads(json.dumps(DEFAULT_SETTINGS))
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as fh:
            stored = json.load(fh)
        return _deep_merge(DEFAULT_SETTINGS, stored)
    except (json.JSONDecodeError, OSError):
        # Corrupted file: fall back to defaults rather than crashing the app.
        return json.loads(json.dumps(DEFAULT_SETTINGS))


def save_settings(settings):
    os.makedirs(DATA_DIR, exist_ok=True)
    merged = _deep_merge(DEFAULT_SETTINGS, settings)
    with _lock:
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(merged, fh, indent=2)
        os.replace(tmp, SETTINGS_PATH)
    return merged


def reset_settings():
    return save_settings(DEFAULT_SETTINGS)
