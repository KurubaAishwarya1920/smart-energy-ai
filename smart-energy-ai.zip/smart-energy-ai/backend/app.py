"""Smart Energy AI - Flask application.

Serves the JSON API and the static frontend from one process, so `python run.py`
is the only thing anyone needs to do.
"""

import csv
import datetime as dt
import io
import os

from flask import Flask, jsonify, request, send_from_directory

from . import ai_provider, analytics, config, data_store, insights, ml

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")


def _load_dotenv():
    """Minimal .env loader so no extra dependency is needed."""
    path = os.path.join(BASE_DIR, ".env")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def create_app():
    _load_dotenv()
    app = Flask(__name__, static_folder=None)

    def ctx():
        settings = config.load_settings()
        return settings, data_store.get_readings(settings)

    # ------------------------------------------------------------ frontend
    @app.route("/")
    def index():
        return send_from_directory(FRONTEND_DIR, "index.html")

    @app.route("/<path:filename>")
    def static_files(filename):
        return send_from_directory(FRONTEND_DIR, filename)

    # ------------------------------------------------------------ api
    @app.get("/api/health")
    def health():
        settings, readings = ctx()
        return jsonify({
            "status": "ok",
            "version": "1.0.0",
            "mode": "demo",
            "hourly_readings": len(readings),
            "ai": ai_provider.status(),
            "server_time": dt.datetime.now().isoformat(timespec="seconds"),
        })

    @app.get("/api/overview")
    def overview():
        settings, readings = ctx()
        range_key = request.args.get("range", settings["ui"]["default_range"])
        payload = analytics.overview(readings, settings, range_key)
        rules = insights.build_insights(readings, settings)
        payload["headline_insight"] = rules["insights"][0] if rules["insights"] else None
        payload["alerts"] = [
            {"severity": i["severity"], "title": i["title"], "category": i["category"]}
            for i in rules["insights"][:4]
        ]
        return jsonify(payload)

    @app.get("/api/consumption")
    def consumption():
        settings, readings = ctx()
        view = request.args.get("view", "daily")
        start = request.args.get("start")
        end = request.args.get("end")

        rows = analytics.daily_series(readings)
        if start:
            rows = [r for r in rows if r["date"] >= start]
        if end:
            rows = [r for r in rows if r["date"] <= end]
        if not start and not end:
            limit = {"daily": 30, "weekly": 84, "monthly": 365}.get(view, 30)
            rows = rows[-limit:]

        complete = [r for r in rows if r["hours_recorded"] >= 24]
        grouped = analytics.group_series(complete, view)
        total = sum(g["kwh"] for g in grouped)
        days = sum(g["days"] for g in grouped) or 1

        previous = analytics.daily_series(readings)
        prev_slice = [r for r in previous if r["date"] < (rows[0]["date"] if rows else "")]
        prev_slice = prev_slice[-len(rows):] if rows else []
        prev_total = sum(r["kwh"] for r in prev_slice)

        detail = []
        for row in rows:
            detail.append({
                "date": row["date"],
                "day_name": dt.date.fromisoformat(row["date"]).strftime("%a"),
                "kwh": row["kwh"],
                "cost": analytics.estimate_bill(row["kwh"], settings, 1)["energy_charge"],
                "peak_kwh": row["peak_kwh"],
                "peak_hour": row["peak_hour"],
                "avg_hourly_kwh": row["avg_hourly_kwh"],
                "status": _usage_status(row["kwh"], total / days),
                "partial": row["hours_recorded"] < 24,
            })

        return jsonify({
            "view": view,
            "series": grouped,
            "detail": list(reversed(detail)),
            "hourly_today": [
                {"hour": r["hour"], "kwh": r["total"]}
                for r in analytics.hours_for_date(readings, dt.date.today().isoformat())
            ],
            "typical_profile": analytics.hourly_profile(
                readings, {r["date"] for r in rows}),
            "summary": {
                "total_kwh": round(total, 1),
                "days": days,
                "avg_kwh": round(total / days, 2),
                "max_kwh": round(max((r["kwh"] for r in complete), default=0), 2),
                "min_kwh": round(min((r["kwh"] for r in complete), default=0), 2),
                "cost": analytics.estimate_bill(total, settings, days)["total"],
                "previous_total_kwh": round(prev_total, 1),
                "change_percent": round((total - prev_total) / prev_total * 100, 1)
                                  if prev_total else None,
            },
            "previous_series": [{"label": r["date"], "kwh": r["kwh"]} for r in prev_slice],
            "excluded_partial_days": len(rows) - len(complete),
            "currency_symbol": settings["tariff"]["currency_symbol"],
        })

    @app.get("/api/appliances")
    def appliances():
        settings, readings = ctx()
        days = int(request.args.get("days", 30))
        rows = analytics.daily_series(readings)[-days:]
        dates = {r["date"] for r in rows}
        breakdown = analytics.appliance_breakdown(readings, settings, dates)
        total_kwh = sum(a["kwh"] for a in breakdown)
        return jsonify({
            "period_days": len(dates),
            "appliances": breakdown,
            "total_kwh": round(total_kwh, 1),
            "total_monthly_cost": round(sum(a["monthly_cost"] for a in breakdown), 0),
            "currency_symbol": settings["tariff"]["currency_symbol"],
            "note": "Appliance-level figures are modelled from typical load profiles for a "
                    "home of this size, not from individual smart plugs.",
        })

    @app.get("/api/insights")
    def api_insights():
        settings, readings = ctx()
        anomalies = ml.detect_anomalies(readings, settings)
        payload = insights.build_insights(readings, settings, anomalies)
        payload["ai"] = ai_provider.status()
        if request.args.get("ai") == "1" and payload["ai"]["enabled"]:
            narrative = ai_provider.narrate(
                payload, analytics.overview(readings, settings, "month"))
            if narrative:
                payload["narrative"] = narrative
                payload["engine"] = "rule-based + " + payload["ai"]["provider"]
            else:
                payload["narrative_error"] = (
                    "The configured AI provider could not be reached. Showing local insights.")
        return jsonify(payload)

    @app.post("/api/ai/ask")
    def ai_ask():
        settings, readings = ctx()
        question = (request.get_json(silent=True) or {}).get("question", "").strip()
        if not question:
            return jsonify({"error": "Type a question first."}), 400
        st = ai_provider.status()
        if not st["enabled"]:
            return jsonify({"enabled": False, "answer": None, "message": st["message"]})
        context = analytics.overview(readings, settings, "month")
        answer = ai_provider.ask(question, {
            "totals": context["totals"], "bill": context["bill"]["total"],
            "efficiency": context["efficiency"],
            "appliances": analytics.appliance_breakdown(
                readings, settings,
                {r["date"] for r in analytics.daily_series(readings)[-30:]})[:5],
        })
        if not answer:
            return jsonify({"enabled": True, "answer": None,
                            "message": "The AI provider could not be reached."})
        return jsonify({"enabled": True, "answer": answer, "provider": st["provider"]})

    @app.get("/api/predictions")
    def predictions():
        settings, readings = ctx()
        return jsonify(ml.forecast(readings, settings))

    @app.get("/api/anomalies")
    def anomalies():
        settings, readings = ctx()
        return jsonify(ml.detect_anomalies(
            readings, settings,
            window=int(request.args.get("window", 14)),
            day_threshold=float(request.args.get("day_z", 2.0)),
            hour_threshold=float(request.args.get("hour_z", 3.0)),
        ))

    @app.get("/api/recommendations")
    def recommendations():
        settings, readings = ctx()
        return jsonify(insights.build_recommendations(readings, settings))

    @app.post("/api/bill/estimate")
    def bill_estimate():
        settings, _ = ctx()
        body = request.get_json(silent=True) or {}
        try:
            kwh = float(body.get("kwh", 0))
            days = int(body.get("days", settings["tariff"]["billing_days"]))
        except (TypeError, ValueError):
            return jsonify({"error": "kWh and days must be numbers."}), 400
        if kwh < 0 or days <= 0:
            return jsonify({"error": "Enter a positive number of units and days."}), 400

        override = body.get("tariff")
        if override:
            settings = dict(settings)
            settings["tariff"] = {**settings["tariff"], **override}
        result = analytics.estimate_bill(kwh, settings, days)
        result["co2_kg"] = analytics.co2_kg(kwh, settings)
        return jsonify(result)

    @app.get("/api/reports/summary")
    def report_summary():
        settings, readings = ctx()
        days = int(request.args.get("days", 30))
        rows = [r for r in analytics.daily_series(readings) if r["hours_recorded"] >= 24][-days:]
        dates = {r["date"] for r in rows}
        total = sum(r["kwh"] for r in rows)
        anomaly = ml.detect_anomalies(readings, settings)
        rec = insights.build_recommendations(readings, settings)
        rules = insights.build_insights(readings, settings, anomaly)
        return jsonify({
            "period": {"start": rows[0]["date"], "end": rows[-1]["date"], "days": len(rows)},
            "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
            "household": settings["household"],
            "totals": {
                "kwh": round(total, 1),
                "avg_daily_kwh": round(total / len(rows), 2),
                "peak_kwh": round(max(r["peak_kwh"] for r in rows), 2),
                "co2_kg": analytics.co2_kg(total, settings),
            },
            "bill": analytics.estimate_bill(total, settings, len(rows)),
            "efficiency": analytics.efficiency_score(
                analytics.daily_series(readings), settings, readings),
            "appliances": analytics.appliance_breakdown(readings, settings, dates),
            "anomalies": anomaly["summary"],
            "top_anomalies": anomaly["events"][:5],
            "insights": rules["insights"][:5],
            "recommendations": rec["recommendations"][:5],
            "daily": [{"date": r["date"], "kwh": r["kwh"]} for r in rows],
            "currency_symbol": settings["tariff"]["currency_symbol"],
        })

    @app.get("/api/export/consumption.csv")
    def export_csv():
        settings, readings = ctx()
        days = int(request.args.get("days", 90))
        rows = analytics.daily_series(readings)[-days:]
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["date", "kwh", "peak_kwh", "peak_hour", "avg_hourly_kwh",
                         "estimated_cost", "source"])
        for row in rows:
            writer.writerow([
                row["date"], row["kwh"], row["peak_kwh"], row["peak_hour"],
                row["avg_hourly_kwh"],
                analytics.estimate_bill(row["kwh"], settings, 1)["energy_charge"],
                "demo data",
            ])
        return buffer.getvalue(), 200, {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": 'attachment; filename="smart-energy-consumption.csv"',
        }

    @app.get("/api/export/hourly.csv")
    def export_hourly():
        settings, readings = ctx()
        days = int(request.args.get("days", 14))
        recent = {r["date"] for r in analytics.daily_series(readings)[-days:]}
        names = list(data_store.APPLIANCE_NAMES)
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["date", "hour", "total_kwh"] + names)
        for r in readings:
            if r["date"] in recent:
                writer.writerow([r["date"], r["hour"], r["total"]]
                                + [r["appliances"][n] for n in names])
        return buffer.getvalue(), 200, {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": 'attachment; filename="smart-energy-hourly.csv"',
        }

    @app.get("/api/settings")
    def get_settings():
        return jsonify(config.load_settings())

    @app.post("/api/settings")
    def post_settings():
        body = request.get_json(silent=True) or {}
        saved = config.save_settings(body)
        data_store.invalidate()
        return jsonify(saved)

    @app.post("/api/settings/reset")
    def reset():
        saved = config.reset_settings()
        data_store.invalidate()
        return jsonify(saved)

    @app.post("/api/demo/regenerate")
    def regenerate():
        settings = config.load_settings()
        body = request.get_json(silent=True) or {}
        seed = body.get("seed")
        if seed is None:
            seed = (settings["demo"]["seed"] + 1) % 999999
        settings["demo"]["seed"] = int(seed)
        config.save_settings(settings)
        data_store.invalidate()
        readings = data_store.get_readings(settings, force=True)
        return jsonify({"status": "regenerated", "seed": int(seed),
                        "hourly_readings": len(readings)})

    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return jsonify({"error": "No such endpoint: " + request.path}), 404
        return send_from_directory(FRONTEND_DIR, "index.html")

    @app.errorhandler(500)
    def server_error(err):  # pragma: no cover
        return jsonify({"error": "Something went wrong on the server.",
                        "detail": str(err)}), 500

    return app


def _usage_status(kwh, average):
    if average <= 0:
        return "Normal"
    ratio = kwh / average
    if ratio >= 1.35:
        return "Very high"
    if ratio >= 1.12:
        return "High"
    if ratio <= 0.75:
        return "Low"
    return "Normal"


app = create_app()

if __name__ == "__main__":  # pragma: no cover
    port = int(os.environ.get("PORT", 5000))
    app.run(host="127.0.0.1", port=port, debug=os.environ.get("FLASK_DEBUG") == "1")
