"""Lightweight local forecasting and anomaly detection.

Deliberately simple and explainable:
  * forecasting  = least-squares linear trend x day-of-week seasonal factors
  * confidence   = walk-forward backtest on held-out days (MAPE)
  * anomalies    = z-score against a rolling window, at day and hour level

No external service is contacted and no trained model file is needed. Outputs
are labelled as estimates everywhere they surface in the UI.
"""

import datetime as dt
import statistics
from collections import defaultdict

from .analytics import daily_series, estimate_bill, _days_in_month


# ------------------------------------------------------------------ forecasting

def _linear_fit(values):
    """Ordinary least squares on y = a + b*x with x = 0..n-1."""
    n = len(values)
    if n < 2:
        return (values[0] if values else 0.0), 0.0
    xs = list(range(n))
    mean_x = sum(xs) / n
    mean_y = sum(values) / n
    denom = sum((x - mean_x) ** 2 for x in xs) or 1.0
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, values)) / denom
    intercept = mean_y - slope * mean_x
    return intercept, slope


def _weekday_factors(rows, window=56):
    recent = rows[-window:]
    overall = statistics.fmean(r["kwh"] for r in recent) or 1.0
    by_day = defaultdict(list)
    for r in recent:
        by_day[r["weekday"]].append(r["kwh"])
    factors = {}
    for wd in range(7):
        vals = by_day.get(wd)
        factors[wd] = (statistics.fmean(vals) / overall) if vals else 1.0
    # Keep factors sane so one odd week cannot distort the forecast.
    return {k: min(max(v, 0.75), 1.3) for k, v in factors.items()}


def _project(rows, horizon, window=60):
    """Return `horizon` daily point forecasts starting the day after rows end."""
    history = [r for r in rows if r["hours_recorded"] >= 24]
    if len(history) < 14:
        history = rows
    train = history[-window:]
    values = [r["kwh"] for r in train]
    intercept, slope = _linear_fit(values)
    factors = _weekday_factors(history)
    last_date = dt.date.fromisoformat(history[-1]["date"])

    out = []
    n = len(values)
    for step in range(1, horizon + 1):
        base = intercept + slope * (n - 1 + step)
        day = last_date + dt.timedelta(days=step)
        value = base * factors[day.weekday()]
        floor = min(values) * 0.6
        out.append({"date": day.isoformat(), "kwh": round(max(value, floor), 2),
                    "weekday": day.weekday()})
    return out, values


def _backtest(rows, holdout=14, window=60):
    """Walk-forward one-step-ahead test to turn accuracy into a confidence figure."""
    history = [r for r in rows if r["hours_recorded"] >= 24]
    if len(history) < holdout + 21:
        return None
    errors = []
    for i in range(len(history) - holdout, len(history)):
        train = history[:i]
        pred, _ = _project(train, 1, window)
        actual = history[i]["kwh"]
        if actual:
            errors.append(abs(pred[0]["kwh"] - actual) / actual)
    if not errors:
        return None
    mape = statistics.fmean(errors) * 100
    return {"mape_percent": round(mape, 1), "tested_days": len(errors)}


def forecast(readings, settings):
    rows = daily_series(readings)
    complete = [r for r in rows if r["hours_recorded"] >= 24]
    horizon = 31
    points, train_values = _project(rows, horizon)

    residual_sd = statistics.pstdev(train_values[-30:]) if len(train_values) >= 5 else 0.0
    bt = _backtest(rows)
    mape = bt["mape_percent"] if bt else 12.0
    confidence = int(max(35, min(95, round(100 - mape * 1.8))))

    next_day = points[0]
    next_week = points[:7]
    week_kwh = sum(p["kwh"] for p in next_week)

    today = dt.date.today()
    days_in_month = _days_in_month(today)
    month_rows = [r for r in rows if r["date"].startswith(today.isoformat()[:7])]
    so_far = sum(r["kwh"] for r in month_rows)
    remaining_days = days_in_month - today.day
    remaining = sum(p["kwh"] for p in points[:remaining_days]) if remaining_days > 0 else 0.0
    month_kwh = so_far + remaining

    band = max(residual_sd, next_day["kwh"] * mape / 100.0)

    history_tail = [{"date": r["date"], "kwh": r["kwh"]} for r in complete[-45:]]
    return {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "method": "Least-squares trend on the last 60 days, adjusted by day-of-week "
                  "factors from the last 8 weeks.",
        "confidence_percent": confidence,
        "accuracy": bt,
        "next_day": {
            "date": next_day["date"],
            "kwh": next_day["kwh"],
            "low": round(max(next_day["kwh"] - band, 0), 2),
            "high": round(next_day["kwh"] + band, 2),
            "cost": estimate_bill(next_day["kwh"], settings, 1)["total"],
        },
        "next_week": {
            "kwh": round(week_kwh, 1),
            "low": round(max(week_kwh - band * 2.6, 0), 1),
            "high": round(week_kwh + band * 2.6, 1),
            "cost": estimate_bill(week_kwh, settings, 7)["total"],
            "days": next_week,
        },
        "month": {
            "kwh": round(month_kwh, 1),
            "so_far_kwh": round(so_far, 1),
            "remaining_kwh": round(remaining, 1),
            "days_remaining": max(remaining_days, 0),
            "bill": estimate_bill(month_kwh, settings, days_in_month),
            "target_kwh": settings["targets"]["monthly_kwh_target"],
        },
        "history": history_tail,
        "forecast": points,
        "disclaimer": "Forecasts are statistical estimates from your own usage pattern. "
                      "Actual consumption will differ - weather, guests and appliance "
                      "faults are not modelled.",
    }


# --------------------------------------------------------------- anomalies

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}


def _suggested_action(appliance):
    actions = {
        "Air Conditioner": "Check the thermostat set point and whether the unit ran while "
                           "nobody was home. A set point of 24-26 C and a clean filter "
                           "usually cuts this load sharply.",
        "Water Heater": "Verify the thermostat cut-off and consider a timer so the heater "
                        "only runs before bath times.",
        "Refrigerator": "Inspect the door seal, leave a gap behind the unit for airflow, and "
                        "avoid loading warm food directly.",
        "Washing Machine": "Move wash cycles outside peak hours and run full loads in cold water.",
        "Television": "Look for the set being left on in an empty room; enable auto power-off.",
        "Lights": "Check for lights left on overnight and switch remaining bulbs to LED.",
        "Fan": "Reduce speed or use timer mode overnight.",
        "Laptop": "Unplug chargers once charged and enable sleep after 10 minutes idle.",
        "Other": "Identify what was plugged in during this window - a pump, iron or heater "
                 "is the usual cause.",
    }
    return actions.get(appliance, "Review what was running during this window.")


def detect_anomalies(readings, settings, window=14, day_threshold=2.0, hour_threshold=3.0):
    rows = daily_series(readings)
    complete = [r for r in rows if r["hours_recorded"] >= 24]
    events = []

    # --- daily level -------------------------------------------------------
    for i in range(window, len(complete)):
        row = complete[i]
        past = [r["kwh"] for r in complete[i - window:i]]
        mean = statistics.fmean(past)
        sd = statistics.pstdev(past)
        if sd < 0.35:
            sd = 0.35
        z = (row["kwh"] - mean) / sd
        if z >= day_threshold:
            severity = "high" if z >= 3.0 else "medium" if z >= 2.5 else "low"
            excess = row["kwh"] - mean
            events.append({
                "id": "day-" + row["date"],
                "level": "day",
                "date": row["date"],
                "window": "Full day",
                "kwh": row["kwh"],
                "expected_kwh": round(mean, 2),
                "excess_kwh": round(excess, 2),
                "z_score": round(z, 2),
                "severity": severity,
                "appliance": None,
                "reason": row.get("anomaly_hint")
                          or "Total consumption was well above the 14-day rolling average.",
                "action": "Compare this day's hourly profile with a normal day to find the window "
                          "that carried the extra load.",
                "extra_cost": estimate_bill(excess, settings, 1)["total"],
            })

    # --- hourly level, last 45 days ---------------------------------------
    recent_dates = [r["date"] for r in complete[-45:]]
    recent = set(recent_dates)
    by_hour = defaultdict(list)
    for r in readings:
        if r["date"] in recent:
            by_hour[r["hour"]].append(r)

    stats = {}
    for hour, items in by_hour.items():
        vals = [i["total"] for i in items]
        mean = statistics.fmean(vals)
        sd = statistics.pstdev(vals) or 0.2
        stats[hour] = (mean, max(sd, 0.15))

    flagged = []
    for r in readings:
        if r["date"] not in recent:
            continue
        mean, sd = stats[r["hour"]]
        z = (r["total"] - mean) / sd
        if z >= hour_threshold:
            flagged.append((r, z, mean))

    # group consecutive flagged hours on the same day into one event
    flagged.sort(key=lambda t: (t[0]["date"], t[0]["hour"]))
    group = []
    for item in flagged:
        if group and item[0]["date"] == group[-1][0]["date"] and \
                item[0]["hour"] == group[-1][0]["hour"] + 1:
            group.append(item)
        else:
            if group:
                events.append(_hour_event(group, settings))
            group = [item]
    if group:
        events.append(_hour_event(group, settings))

    # If an hourly event already explains most of a day's excess, keep only the
    # hourly one - it is the more useful of the two and avoids double counting.
    hour_excess = defaultdict(float)
    for e in events:
        if e["level"] == "hour":
            hour_excess[e["date"]] += e["excess_kwh"]
    events = [e for e in events
              if not (e["level"] == "day"
                      and hour_excess.get(e["date"], 0) >= 0.6 * e["excess_kwh"])]

    events.sort(key=lambda e: (SEVERITY_ORDER[e["severity"]], e["date"]), reverse=False)
    events.sort(key=lambda e: e["date"], reverse=True)

    normal_days = len(complete) - len({e["date"] for e in events})
    total_excess = round(sum(e["excess_kwh"] for e in events), 2)
    return {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "method": "Z-score against a 14-day rolling average for daily totals, and against the "
                  "same hour-of-day across the last 45 days for hourly spikes.",
        "thresholds": {"daily_z": day_threshold, "hourly_z": hour_threshold, "window_days": window},
        "summary": {
            "days_analysed": len(complete),
            "normal_days": max(normal_days, 0),
            "events": len(events),
            "high": sum(1 for e in events if e["severity"] == "high"),
            "medium": sum(1 for e in events if e["severity"] == "medium"),
            "low": sum(1 for e in events if e["severity"] == "low"),
            "excess_kwh": total_excess,
            "excess_cost": estimate_bill(total_excess, settings, 30)["total"],
        },
        "events": events[:40],
        "daily": [{"date": r["date"], "kwh": r["kwh"]} for r in complete[-60:]],
    }


def _hour_event(group, settings):
    rows = [g[0] for g in group]
    zs = [g[1] for g in group]
    means = [g[2] for g in group]
    date = rows[0]["date"]
    start = rows[0]["hour"]
    end = rows[-1]["hour"]
    kwh = sum(r["total"] for r in rows)
    expected = sum(means)
    excess = kwh - expected
    peak_z = max(zs)
    severity = "high" if peak_z >= 4.5 or len(rows) >= 4 else "medium" if peak_z >= 3.5 else "low"

    # Attribute the spike to whichever appliance deviated most.
    deviations = defaultdict(float)
    for r in rows:
        for name, value in r["appliances"].items():
            deviations[name] += value
    appliance = max(deviations, key=deviations.get)

    hint = next((r.get("anomaly_hint") for r in rows if r.get("anomaly_hint")), None)
    day_name = dt.date.fromisoformat(date).strftime("%A")
    window = "%s, %s to %s" % (day_name, _fmt_hour(start), _fmt_hour(end + 1))
    return {
        "id": "hour-%s-%02d" % (date, start),
        "level": "hour",
        "date": date,
        "window": window,
        "kwh": round(kwh, 2),
        "expected_kwh": round(expected, 2),
        "excess_kwh": round(excess, 2),
        "z_score": round(peak_z, 2),
        "severity": severity,
        "appliance": appliance,
        "reason": hint or ("%s accounted for most of the load in this window, well above its "
                           "normal level for these hours." % appliance),
        "action": _suggested_action(appliance),
        "extra_cost": estimate_bill(max(excess, 0), settings, 1)["total"],
    }


def _fmt_hour(hour):
    hour = hour % 24
    suffix = "AM" if hour < 12 else "PM"
    display = hour % 12 or 12
    return "%d %s" % (display, suffix)
