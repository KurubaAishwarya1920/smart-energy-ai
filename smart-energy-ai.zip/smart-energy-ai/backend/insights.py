"""Rule-based energy intelligence.

This is the DEFAULT brain of the app and needs no API key, no model download and
no internet. Each insight states what was measured, what it means, what it might
save and what to do next. An optional LLM can rewrite these into a narrative
(see ai_provider.py) but never replaces them.
"""

import datetime as dt
import statistics
from collections import defaultdict

from .analytics import (appliance_breakdown, cost_of, daily_series, efficiency_score,
                        hourly_profile)


def _rate(settings):
    return settings["tariff"]["slabs"][-1]["rate"]


def _money(settings, kwh):
    return round(max(kwh, 0) * _rate(settings), 0)


def build_insights(readings, settings, anomalies=None):
    rows = daily_series(readings)
    complete = [r for r in rows if r["hours_recorded"] >= 24]
    recent = complete[-30:]
    recent_dates = {r["date"] for r in recent}
    profile = hourly_profile(readings, recent_dates)
    symbol = settings["tariff"]["currency_symbol"]
    insights = []

    day_kwh = sum(profile[6:17])
    evening_kwh = sum(profile[17:23])
    # Compare like for like: per-hour averages, not raw block totals.
    day_rate = day_kwh / 11 if day_kwh else 0
    evening_rate = evening_kwh / 6 if evening_kwh else 0
    if day_rate:
        diff = (evening_rate - day_rate) / day_rate * 100
        if abs(diff) >= 5:
            shift_kwh = evening_kwh * 0.15 * 30
            insights.append({
                "id": "evening-load",
                "category": "Usage pattern",
                "severity": "warning" if diff > 15 else "info",
                "title": "Evening consumption runs %.0f%% %s than daytime"
                         % (abs(diff), "higher" if diff > 0 else "lower"),
                "explanation": "Between 5 PM and 11 PM you average %.2f kWh per hour, against "
                               "%.2f kWh per hour through the day. Evening load stacks lighting, "
                               "cooling, cooking and entertainment into the same few hours."
                               % (evening_rate, day_rate),
                "saving_kwh": round(shift_kwh, 1),
                "saving_cost": _money(settings, shift_kwh),
                "action": "Move the washing machine, water heater and any ironing to before "
                          "4 PM so the evening block carries less.",
                "confidence": "high",
            })

    peak_hour = max(range(24), key=lambda h: profile[h])
    window_start = max(peak_hour - 1, 0)
    peak_block = sum(profile[window_start:window_start + 3])
    total = sum(profile) or 1
    insights.append({
        "id": "peak-window",
        "category": "Peak load",
        "severity": "info",
        "title": "Peak usage falls between %s and %s"
                 % (_fmt(window_start), _fmt(window_start + 3)),
        "explanation": "That three-hour window carries %.0f%% of a typical day's energy, "
                       "topping out at %.2f kWh in the %s hour."
                       % (peak_block / total * 100, profile[peak_hour], _fmt(peak_hour)),
        "saving_kwh": round(peak_block * 0.12 * 30, 1),
        "saving_cost": _money(settings, peak_block * 0.12 * 30),
        "action": "Stagger high-load appliances so no more than one heavy device runs in "
                  "this window.",
        "confidence": "high",
    })

    appliances = appliance_breakdown(readings, settings, recent_dates)
    if appliances:
        top = appliances[0]
        insights.append({
            "id": "top-appliance",
            "category": "Appliances",
            "severity": "warning" if top["share_percent"] > 35 else "info",
            "title": "%s is your largest load at %.0f%% of consumption"
                     % (top["name"], top["share_percent"]),
            "explanation": "It draws about %.1f kWh a day across roughly %.1f hours of "
                           "run time, which works out to around %s%s a month at your top slab rate."
                           % (top["daily_kwh"], top["hours_per_day"], symbol,
                              format(int(top["monthly_cost"]), ",")),
            "saving_kwh": round(top["monthly_kwh"] * 0.12, 1),
            "saving_cost": _money(settings, top["monthly_kwh"] * 0.12),
            "action": "A 10-12% reduction here is worth more than savings on every other "
                      "appliance combined. Start with run hours, not with switching it off.",
            "confidence": "high",
        })

    # Standby / base load: the floor the home never drops below.
    base = min(profile[1:5]) if profile else 0
    base_month = base * 24 * 30
    daily_avg = statistics.fmean(r["kwh"] for r in recent) if recent else 0
    base_share = base * 24 / daily_avg * 100 if daily_avg else 0
    if base >= 0.1:
        # Only part of the overnight floor is avoidable - the refrigerator is not.
        avoidable = base_month * 0.15
        insights.append({
            "id": "base-load",
            "category": "Standby",
            "severity": "warning" if base_share > 45 else "info",
            "title": "Consumption never drops below %.2f kWh an hour overnight" % base,
            "explanation": "Held for a whole month that floor is about %.0f kWh, roughly %.0f%% of "
                           "everything you use. The refrigerator and fans account for most of it, "
                           "but set-top boxes, chargers, routers and idle screens sit inside this "
                           "number too." % (base_month, base_share),
            "saving_kwh": round(avoidable, 1),
            "saving_cost": _money(settings, avoidable),
            "action": "Put entertainment and desk electronics on switched power strips and turn "
                      "them off at night. Expect to remove roughly a sixth of this floor, not "
                      "all of it.",
            "confidence": "medium",
        })

    weekend = [r["kwh"] for r in recent if r["weekday"] >= 5]
    weekday = [r["kwh"] for r in recent if r["weekday"] < 5]
    if weekend and weekday:
        wd = statistics.fmean(weekday)
        we = statistics.fmean(weekend)
        gap = (we - wd) / wd * 100 if wd else 0
        if abs(gap) >= 8:
            insights.append({
                "id": "weekend-gap",
                "category": "Usage pattern",
                "severity": "info",
                "title": "Weekends use %.0f%% %s energy than weekdays"
                         % (abs(gap), "more" if gap > 0 else "less"),
                "explanation": "Weekday average is %.1f kWh a day against %.1f kWh at weekends. "
                               "Longer occupancy means cooling and entertainment run for more hours."
                               % (wd, we),
                "saving_kwh": round(max(we - wd, 0) * 8, 1),
                "saving_cost": _money(settings, max(we - wd, 0) * 8),
                "action": "Set the air conditioner to a timer on weekend afternoons rather than "
                          "leaving it running continuously.",
                "confidence": "medium",
            })

    if len(complete) >= 60:
        this_30 = statistics.fmean(r["kwh"] for r in complete[-30:])
        prev_30 = statistics.fmean(r["kwh"] for r in complete[-60:-30])
        change = (this_30 - prev_30) / prev_30 * 100 if prev_30 else 0
        if abs(change) >= 4:
            insights.append({
                "id": "trend",
                "category": "Trend",
                "severity": "critical" if change > 15 else "warning" if change > 0 else "info",
                "title": "Consumption is %s %.0f%% against the previous month"
                         % ("up" if change > 0 else "down", abs(change)),
                "explanation": "Daily average moved from %.1f kWh to %.1f kWh. Seasonal cooling "
                               "demand explains part of this, but the gap is larger than the "
                               "seasonal swing alone." % (prev_30, this_30),
                "saving_kwh": round(max(this_30 - prev_30, 0) * 30, 1),
                "saving_cost": _money(settings, max(this_30 - prev_30, 0) * 30),
                "action": "Check the Anomaly Detection page for the specific days that pushed "
                          "the average up.",
                "confidence": "high",
            })

    target = settings["targets"]["monthly_kwh_target"]
    projected = statistics.fmean(r["kwh"] for r in recent) * 30 if recent else 0
    if target:
        over = projected - target
        insights.append({
            "id": "target",
            "category": "Target",
            "severity": "warning" if over > target * 0.05 else "info",
            "title": "On track for %.0f kWh against your %.0f kWh target" % (projected, target),
            "explanation": ("You are %.0f kWh over the target you set, worth about %s%s on the "
                            "bill." % (over, symbol, format(int(cost_of(over, settings, 30) -
                                                              settings["tariff"]["fixed_charge"]), ","))
                            if over > 0 else
                            "You are %.0f kWh under target with the current pattern." % abs(over)),
            "saving_kwh": round(max(over, 0), 1),
            "saving_cost": _money(settings, max(over, 0)),
            "action": "Trimming %.1f kWh a day closes the gap." % (abs(over) / 30) if over > 0
                      else "Hold the current pattern.",
            "confidence": "medium",
        })

    if anomalies and anomalies["summary"]["events"]:
        s = anomalies["summary"]
        insights.append({
            "id": "anomaly-roundup",
            "category": "Anomalies",
            "severity": "critical" if s["high"] else "warning",
            "title": "%d unusual consumption events found in this period" % s["events"],
            "explanation": "Together they account for about %.1f kWh of extra energy. %d were "
                           "flagged as high severity." % (s["excess_kwh"], s["high"]),
            "saving_kwh": s["excess_kwh"],
            "saving_cost": _money(settings, s["excess_kwh"]),
            "action": "Open Anomaly Detection and work through the high-severity events first.",
            "confidence": "high",
        })

    score = efficiency_score(complete, settings, readings)
    weakest = min(score["components"], key=lambda c: c["points"] / c["max"]) if score["components"] else None
    if weakest:
        insights.append({
            "id": "efficiency",
            "category": "Efficiency",
            "severity": "info",
            "title": "Efficiency score %d of 100 - %s" % (score["score"], score["band"]),
            "explanation": "The weakest component is %s: %s."
                           % (weakest["label"].lower(), weakest["detail"]),
            "saving_kwh": 0,
            "saving_cost": 0,
            "action": "Improving this one component moves the score most.",
            "confidence": "medium",
        })

    order = {"critical": 0, "warning": 1, "info": 2}
    insights.sort(key=lambda i: (order[i["severity"]], -i["saving_cost"]))
    return {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "engine": "rule-based",
        "insights": insights,
        "total_saving_kwh": round(sum(i["saving_kwh"] for i in insights), 1),
        "total_saving_cost": round(sum(i["saving_cost"] for i in insights), 0),
        "note": "Generated locally from your consumption data. No external service is used. "
                "Findings can overlap, so the headline saving figure is an upper bound rather "
                "than a sum you can bank.",
    }


# ------------------------------------------------------------ recommendations

CATALOGUE = [
    {
        "id": "ac-setpoint",
        "title": "Raise the air conditioner set point to 24-26 C",
        "detail": "Each degree lower costs roughly 6% more energy. Pairing the AC with a ceiling "
                  "fan keeps the same comfort at a higher set point.",
        "appliance": "Air Conditioner", "share": 0.10,
        "difficulty": "Easy", "effort": "One-time", "cost_to_do": "Free",
    },
    {
        "id": "ac-service",
        "title": "Clean the air conditioner filter every month",
        "detail": "A clogged filter forces the compressor to run longer for the same cooling. "
                  "This is the single cheapest cooling saving available.",
        "appliance": "Air Conditioner", "share": 0.07,
        "difficulty": "Easy", "effort": "Monthly", "cost_to_do": "Free",
    },
    {
        "id": "ac-timer",
        "title": "Use a sleep timer instead of running cooling all night",
        "detail": "Cooling for the first three hours of sleep and letting a fan carry the rest "
                  "avoids the overnight compressor cycling that shows up in your night-time data.",
        "appliance": "Air Conditioner", "share": 0.12,
        "difficulty": "Easy", "effort": "Nightly", "cost_to_do": "Free",
    },
    {
        "id": "heater-timer",
        "title": "Put the water heater on a timer",
        "detail": "Heating water once before bath times, rather than holding a tank hot all "
                  "evening, removes most of the standing loss.",
        "appliance": "Water Heater", "share": 0.28,
        "difficulty": "Moderate", "effort": "One-time", "cost_to_do": "Low",
    },
    {
        "id": "fridge-seal",
        "title": "Check the refrigerator door seal and give it breathing room",
        "detail": "A weak seal or a unit pushed flat against the wall makes the compressor run "
                  "far longer than it should.",
        "appliance": "Refrigerator", "share": 0.12,
        "difficulty": "Easy", "effort": "One-time", "cost_to_do": "Free",
    },
    {
        "id": "wash-offpeak",
        "title": "Run the washing machine before 4 PM on full loads",
        "detail": "Full cold-water loads outside the evening peak cut both energy and the "
                  "chance of pushing into a higher tariff slab.",
        "appliance": "Washing Machine", "share": 0.22,
        "difficulty": "Easy", "effort": "Per wash", "cost_to_do": "Free",
    },
    {
        "id": "led",
        "title": "Replace any remaining tube lights and CFLs with LED",
        "detail": "LEDs draw roughly a fifth of the power for the same light and pay for "
                  "themselves within a few months at your usage level.",
        "appliance": "Lights", "share": 0.45,
        "difficulty": "Easy", "effort": "One-time", "cost_to_do": "Medium",
    },
    {
        "id": "standby",
        "title": "Switch entertainment and desk electronics off at the strip",
        "detail": "Set-top boxes, monitors and chargers hold a constant draw all night. A "
                  "switched strip removes it entirely.",
        "appliance": "Other", "share": 0.20,
        "difficulty": "Easy", "effort": "Nightly", "cost_to_do": "Low",
    },
    {
        "id": "tv-auto-off",
        "title": "Turn on auto power-off for the television",
        "detail": "Your data shows the set drawing power well past the hours anyone is likely "
                  "watching.",
        "appliance": "Television", "share": 0.15,
        "difficulty": "Easy", "effort": "One-time", "cost_to_do": "Free",
    },
    {
        "id": "fan-speed",
        "title": "Drop ceiling fans one speed overnight",
        "detail": "Fan power rises sharply with speed, so one step down saves more than it feels "
                  "like it should.",
        "appliance": "Fan", "share": 0.18,
        "difficulty": "Easy", "effort": "Nightly", "cost_to_do": "Free",
    },
    {
        "id": "laptop-charge",
        "title": "Unplug laptop chargers once charged",
        "detail": "A charger left plugged in keeps drawing a small current all day.",
        "appliance": "Laptop", "share": 0.15,
        "difficulty": "Easy", "effort": "Daily", "cost_to_do": "Free",
    },
]


def build_recommendations(readings, settings):
    rows = daily_series(readings)
    recent_dates = {r["date"] for r in rows[-30:]}
    appliances = {a["name"]: a for a in appliance_breakdown(readings, settings, recent_dates)}
    rate = _rate(settings)

    out = []
    for item in CATALOGUE:
        appliance = appliances.get(item["appliance"])
        if not appliance:
            continue
        saving_kwh = appliance["monthly_kwh"] * item["share"]
        if saving_kwh < 0.8:
            continue
        out.append({
            "id": item["id"],
            "title": item["title"],
            "detail": item["detail"],
            "appliance": item["appliance"],
            "difficulty": item["difficulty"],
            "effort": item["effort"],
            "cost_to_do": item["cost_to_do"],
            "saving_kwh_month": round(saving_kwh, 1),
            "saving_cost_month": round(saving_kwh * rate, 0),
            "saving_cost_year": round(saving_kwh * rate * 12, 0),
            "co2_saved_kg_year": round(saving_kwh * 12 * settings["environment"]["co2_factor"], 1),
        })

    out.sort(key=lambda r: r["saving_cost_month"], reverse=True)
    for i, row in enumerate(out, start=1):
        row["rank"] = i
    total_kwh = sum(r["saving_kwh_month"] for r in out)
    return {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "recommendations": out,
        "totals": {
            "kwh_month": round(total_kwh, 1),
            "cost_month": round(total_kwh * rate, 0),
            "cost_year": round(total_kwh * rate * 12, 0),
            "co2_kg_year": round(total_kwh * 12 * settings["environment"]["co2_factor"], 1),
        },
        "note": "Savings are estimates based on your own appliance mix and the tariff in "
                "Settings. Treat them as a ranking of what to try first, not a guarantee.",
    }


def _fmt(hour):
    hour = hour % 24
    suffix = "AM" if hour < 12 else "PM"
    return "%d %s" % (hour % 12 or 12, suffix)
