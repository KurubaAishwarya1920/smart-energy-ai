"""Aggregation, tariff maths, appliance analysis and efficiency scoring.

Pure Python only - no numpy/pandas - so the project installs with one small
dependency (Flask) and runs on any machine.
"""

import datetime as dt
from collections import defaultdict

from .data_store import APPLIANCE_PROFILES


# ---------------------------------------------------------------- aggregation

def daily_series(readings):
    """Collapse hourly readings into one row per day."""
    buckets = defaultdict(list)
    for r in readings:
        buckets[r["date"]].append(r)

    rows = []
    for date in sorted(buckets):
        hours = sorted(buckets[date], key=lambda r: r["hour"])
        totals = [h["total"] for h in hours]
        peak = max(hours, key=lambda h: h["total"])
        rows.append({
            "date": date,
            "kwh": round(sum(totals), 3),
            "hours_recorded": len(hours),
            "peak_kwh": round(peak["total"], 3),
            "peak_hour": peak["hour"],
            "avg_hourly_kwh": round(sum(totals) / len(totals), 3),
            "weekday": hours[0]["weekday"],
            "anomaly_hint": next((h.get("anomaly_hint") for h in hours if h.get("anomaly_hint")), None),
        })
    return rows


def hourly_profile(readings, dates=None):
    """Average kWh per hour-of-day across the given dates."""
    sums = defaultdict(float)
    counts = defaultdict(int)
    for r in readings:
        if dates and r["date"] not in dates:
            continue
        sums[r["hour"]] += r["total"]
        counts[r["hour"]] += 1
    return [round(sums[h] / counts[h], 3) if counts[h] else 0.0 for h in range(24)]


def hours_for_date(readings, date):
    rows = [r for r in readings if r["date"] == date]
    return sorted(rows, key=lambda r: r["hour"])


def group_series(daily, view):
    """Roll daily rows up into weekly or monthly buckets."""
    if view == "daily":
        return [{"label": row["date"], "key": row["date"], "kwh": row["kwh"],
                 "days": 1, "peak_kwh": row["peak_kwh"]} for row in daily]

    buckets = defaultdict(list)
    for row in daily:
        d = dt.date.fromisoformat(row["date"])
        if view == "weekly":
            monday = d - dt.timedelta(days=d.weekday())
            key = monday.isoformat()
            label = "Week of " + monday.strftime("%d %b")
        else:
            key = d.strftime("%Y-%m")
            label = d.strftime("%b %Y")
        buckets[key].append((label, row))

    out = []
    for key in sorted(buckets):
        rows = [r for _, r in buckets[key]]
        label = buckets[key][0][0]
        out.append({
            "label": label,
            "key": key,
            "kwh": round(sum(r["kwh"] for r in rows), 2),
            "days": len(rows),
            "peak_kwh": round(max(r["peak_kwh"] for r in rows), 3),
        })
    return out


def slice_by_range(daily, range_key, today=None):
    """Return (rows, previous_rows) for day / week / month / year."""
    today = today or dt.date.today()
    # Today is still in progress, so it would drag every average down. It gets its
    # own figure on the dashboard instead.
    daily = [r for r in daily if r.get("hours_recorded", 24) >= 24]
    if not daily:
        return [], []
    if range_key == "day":
        span = 1
    elif range_key == "week":
        span = 7
    elif range_key == "year":
        span = 365
    else:
        span = 30
    current = daily[-span:]
    previous = daily[-2 * span:-span] if len(daily) >= span + 1 else []
    return current, previous


# ---------------------------------------------------------------- tariff maths

def estimate_bill(kwh, settings, days=None):
    """Slab-based estimate. Every number here is an assumption the user can edit."""
    tariff = settings["tariff"]
    days = days or tariff.get("billing_days", 30)
    # Slabs are defined for a 30-day billing cycle; scale the boundaries when the
    # period is shorter or longer so a 7-day estimate is not pushed into top slabs.
    scale = max(days, 1) / 30.0

    remaining = max(float(kwh), 0.0)
    consumed = 0.0
    lines = []
    for slab in tariff["slabs"]:
        if remaining <= 0:
            break
        upto = slab["upto"]
        if upto is None:
            units = remaining
            label = "Above %g units" % (consumed / scale if scale else consumed)
        else:
            limit = upto * scale
            units = min(remaining, max(limit - consumed, 0.0))
            label = "%g\u2013%g units" % (consumed / scale if scale else 0, upto)
        if units <= 0:
            continue
        amount = units * slab["rate"]
        lines.append({
            "slab": label,
            "units": round(units, 2),
            "rate": slab["rate"],
            "amount": round(amount, 2),
        })
        consumed += units
        remaining -= units

    energy_charge = round(sum(l["amount"] for l in lines), 2)
    fixed_charge = round(tariff.get("fixed_charge", 0.0) * scale, 2)
    duty = round((energy_charge + fixed_charge) * tariff.get("duty_percent", 0.0) / 100.0, 2)
    total = round(energy_charge + fixed_charge + duty, 2)
    return {
        "kwh": round(float(kwh), 2),
        "days": days,
        "lines": lines,
        "energy_charge": energy_charge,
        "fixed_charge": fixed_charge,
        "duty": duty,
        "duty_percent": tariff.get("duty_percent", 0.0),
        "total": total,
        "effective_rate": round(total / kwh, 2) if kwh else 0.0,
        "currency_symbol": tariff.get("currency_symbol", "\u20b9"),
        "disclaimer": "Estimate only, based on the tariff you configured in Settings. "
                      "It is not a bill from your electricity provider.",
    }


def cost_of(kwh, settings, days=30):
    return estimate_bill(kwh, settings, days)["total"]


def co2_kg(kwh, settings):
    return round(float(kwh) * settings["environment"]["co2_factor"], 2)


# ------------------------------------------------------------ appliance view

def appliance_breakdown(readings, settings, dates=None):
    dates = set(dates) if dates else None
    sums = defaultdict(float)
    active_hours = defaultdict(float)
    day_set = set()
    for r in readings:
        if dates is not None and r["date"] not in dates:
            continue
        day_set.add(r["date"])
        for name, value in r["appliances"].items():
            sums[name] += value
            profile = APPLIANCE_PROFILES[name]
            full_hour = profile["base_kwh"]
            if full_hour:
                active_hours[name] += min(value / full_hour, 1.0)

    n_days = max(len(day_set), 1)
    total = sum(sums.values()) or 1.0
    monthly_scale = 30.0 / n_days

    rows = []
    for name, kwh in sums.items():
        profile = APPLIANCE_PROFILES[name]
        monthly_kwh = kwh * monthly_scale
        share = kwh / total * 100.0
        hours_per_day = active_hours[name] / n_days
        label, benchmark, ratio = _appliance_efficiency(name, monthly_kwh)
        rows.append({
            "name": name,
            "category": profile["category"],
            "rated_w": profile["rated_w"],
            "kwh": round(kwh, 2),
            "monthly_kwh": round(monthly_kwh, 2),
            "daily_kwh": round(kwh / n_days, 2),
            "share_percent": round(share, 1),
            "hours_per_day": round(hours_per_day, 1),
            "monthly_cost": round(monthly_kwh * _marginal_rate(settings), 2),
            "efficiency": label,
            "benchmark_monthly_kwh": benchmark,
            "vs_benchmark": ratio,
        })

    rows.sort(key=lambda r: r["kwh"], reverse=True)
    for i, row in enumerate(rows, start=1):
        row["rank"] = i
    return rows


def _marginal_rate(settings):
    """Rate of the highest slab a typical month reaches - used for per-appliance cost."""
    slabs = settings["tariff"]["slabs"]
    return slabs[-1]["rate"] if slabs else 7.0


# Typical monthly kWh for each appliance in a 2-3 room home. Used only to label
# an appliance, never to claim a measurement.
BENCHMARK_MONTHLY_KWH = {
    "Air Conditioner": 100.0,
    "Refrigerator": 45.0,
    "Water Heater": 30.0,
    "Washing Machine": 14.0,
    "Television": 14.0,
    "Lights": 30.0,
    "Fan": 32.0,
    "Laptop": 12.0,
    "Other": 30.0,
}


def _appliance_efficiency(name, monthly_kwh):
    benchmark = BENCHMARK_MONTHLY_KWH.get(name, 25.0)
    ratio = monthly_kwh / benchmark if benchmark else 1.0
    if ratio <= 1.0:
        label = "Efficient"
    elif ratio <= 1.25:
        label = "Watch"
    else:
        label = "High usage"
    return label, round(benchmark, 1), round(ratio, 2)


# ------------------------------------------------------------ scoring & summary

def efficiency_score(daily, settings, readings=None):
    """0-100 composite. Explained on screen so it never looks like a magic number."""
    daily = [r for r in daily if r.get("hours_recorded", 24) >= 24]
    if not daily:
        return {"score": 0, "band": "No data", "components": []}

    recent = daily[-30:]
    occupants = max(settings["household"].get("occupants", 1), 1)
    baseline = settings["targets"]["efficiency_baseline_kwh_per_person_day"]
    avg_per_person = sum(r["kwh"] for r in recent) / len(recent) / occupants

    # 1. Intensity vs baseline (50 pts)
    ratio = avg_per_person / baseline if baseline else 1
    intensity = max(0.0, min(50.0, 50.0 * (1.6 - ratio) / 0.8))

    # 2. Peak-hour discipline (25 pts): share of energy used in peak window
    peak_hours = set(settings["targets"]["peak_hours"])
    peak_share = 0.30
    if readings:
        recent_dates = {r["date"] for r in recent}
        peak_kwh = sum(r["total"] for r in readings
                       if r["date"] in recent_dates and r["hour"] in peak_hours)
        total_kwh = sum(r["total"] for r in readings if r["date"] in recent_dates) or 1
        peak_share = peak_kwh / total_kwh
    ideal = len(peak_hours) / 24.0
    peak_points = max(0.0, min(25.0, 25.0 * (1 - (peak_share - ideal) / 0.25)))

    # 3. Consistency (25 pts): lower day-to-day swing scores better
    values = [r["kwh"] for r in recent]
    mean = sum(values) / len(values)
    sd = (sum((v - mean) ** 2 for v in values) / len(values)) ** 0.5
    cv = sd / mean if mean else 0
    consistency = max(0.0, min(25.0, 25.0 * (1 - cv / 0.35)))

    score = int(round(intensity + peak_points + consistency))
    score = max(0, min(100, score))
    band = ("Excellent" if score >= 85 else "Good" if score >= 70
            else "Fair" if score >= 55 else "Needs attention")
    return {
        "score": score,
        "band": band,
        "components": [
            {"label": "Usage per person", "points": round(intensity, 1), "max": 50,
             "detail": "%.1f kWh per person each day against a %.1f kWh baseline"
                       % (avg_per_person, baseline)},
            {"label": "Peak-hour discipline", "points": round(peak_points, 1), "max": 25,
             "detail": "%.0f%% of energy is used during your peak window" % (peak_share * 100)},
            {"label": "Day-to-day consistency", "points": round(consistency, 1), "max": 25,
             "detail": "Daily usage varies by about %.0f%%" % (cv * 100)},
        ],
    }


def overview(readings, settings, range_key="month"):
    daily = daily_series(readings)
    current, previous = slice_by_range(daily, range_key)
    today_iso = dt.date.today().isoformat()
    today_row = next((r for r in daily if r["date"] == today_iso), None)

    month_prefix = today_iso[:7]
    month_rows = [r for r in daily if r["date"].startswith(month_prefix)]
    month_kwh = sum(r["kwh"] for r in month_rows)
    # Project the month forward for the bill figure people actually care about,
    # using complete days so a half-finished today does not deflate the estimate.
    complete_month = [r for r in month_rows if r["hours_recorded"] >= 24]
    basis = complete_month or month_rows
    days_in_month = _days_in_month(dt.date.today())
    projected_month_kwh = (sum(r["kwh"] for r in basis) / max(len(basis), 1)) * days_in_month

    range_kwh = sum(r["kwh"] for r in current)
    prev_kwh = sum(r["kwh"] for r in previous)
    change = ((range_kwh - prev_kwh) / prev_kwh * 100.0) if prev_kwh else None

    peak_row = max(current, key=lambda r: r["peak_kwh"]) if current else None
    score = efficiency_score(daily, settings, readings)
    bill = estimate_bill(projected_month_kwh, settings, days_in_month)

    return {
        "range": range_key,
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "demo_label": settings["demo"]["label"],
        "currency_symbol": settings["tariff"]["currency_symbol"],
        "totals": {
            "lifetime_kwh": round(sum(r["kwh"] for r in daily), 1),
            "range_kwh": round(range_kwh, 1),
            "range_change_percent": round(change, 1) if change is not None else None,
            "today_kwh": round(today_row["kwh"], 2) if today_row else 0.0,
            "today_hours": today_row["hours_recorded"] if today_row else 0,
            "month_kwh": round(month_kwh, 1),
            "projected_month_kwh": round(projected_month_kwh, 1),
            "avg_daily_kwh": round(range_kwh / len(current), 2) if current else 0.0,
            "peak_kwh": round(peak_row["peak_kwh"], 2) if peak_row else 0.0,
            "peak_hour": peak_row["peak_hour"] if peak_row else None,
            "peak_date": peak_row["date"] if peak_row else None,
            "co2_kg": co2_kg(range_kwh, settings),
            "month_co2_kg": co2_kg(projected_month_kwh, settings),
            "trees_equivalent": round(
                co2_kg(projected_month_kwh * 12, settings)
                / settings["environment"]["tree_offset_kg_per_year"], 1),
        },
        "bill": bill,
        "efficiency": score,
        "trend": [{"date": r["date"], "kwh": r["kwh"]} for r in current],
        "today_hourly": [{"hour": r["hour"], "kwh": r["total"]}
                         for r in hours_for_date(readings, today_iso)],
        "previous_trend": [{"date": r["date"], "kwh": r["kwh"]} for r in previous],
        "today_profile": [r["total"] for r in hours_for_date(readings, today_iso)],
        "typical_profile": hourly_profile(readings, {r["date"] for r in daily[-30:]}),
        "target_month_kwh": settings["targets"]["monthly_kwh_target"],
    }


def _days_in_month(day):
    if day.month == 12:
        nxt = dt.date(day.year + 1, 1, 1)
    else:
        nxt = dt.date(day.year, day.month + 1, 1)
    return (nxt - dt.date(day.year, day.month, 1)).days
