"""Build a single self-contained HTML file from the running project.

This does NOT change the project. It snapshots what the API currently returns
and inlines the real CSS and JavaScript, so the same interface can be opened
without Python running. The local Flask app remains the real application.

    python tools/build_demo.py
"""

import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from backend.app import create_app  # noqa: E402

FRONTEND = os.path.join(BASE, "frontend")
OUT = os.path.join(BASE, "dist", "smart-energy-ai-demo.html")


def read(*parts):
    with open(os.path.join(FRONTEND, *parts), "r", encoding="utf-8") as fh:
        return fh.read()


def snapshot():
    client = create_app().test_client()
    first = client.get("/api/consumption?view=daily&start=1970-01-01").get_json()

    data = {
        "health": client.get("/api/health").get_json(),
        "settings": client.get("/api/settings").get_json(),
        "appliances": client.get("/api/appliances?days=30").get_json(),
        "insights": client.get("/api/insights").get_json(),
        "predictions": client.get("/api/predictions").get_json(),
        "recommendations": client.get("/api/recommendations").get_json(),
        "consumption": {
            "daily": first,
            "weekly": client.get("/api/consumption?view=weekly").get_json(),
            "monthly": client.get("/api/consumption?view=monthly").get_json(),
        },
        "overview": {},
        "anomalies": {},
        "report": {},
    }
    for rng in ("day", "week", "month", "year"):
        data["overview"][rng] = client.get("/api/overview?range=" + rng).get_json()
    for name, params in (("strict", "day_z=2.6&hour_z=3.8"),
                         ("normal", "day_z=2.0&hour_z=3.0"),
                         ("loose", "day_z=1.6&hour_z=2.4")):
        data["anomalies"][name] = client.get("/api/anomalies?" + params).get_json()
    for days in ("7", "30", "90"):
        data["report"][days] = client.get("/api/reports/summary?days=" + days).get_json()
    return data


SHIM = r"""
/* Offline stand-in for api.js. Serves the baked snapshot instead of Flask.
   The real project talks to the real API; this exists only so the interface
   can be opened as a single file. */
(function (global) {
  'use strict';
  var DATA = global.__SNAPSHOT__;
  function ok(value) { return Promise.resolve(JSON.parse(JSON.stringify(value))); }

  function estimateBill(kwh, days, tariff) {
    var scale = Math.max(days, 1) / 30;
    var remaining = Math.max(kwh, 0), consumed = 0, lines = [];
    tariff.slabs.forEach(function (slab, i) {
      if (remaining <= 0) return;
      var units, label;
      if (slab.upto === null || slab.upto === undefined || slab.upto === '') {
        units = remaining;
        label = 'Above ' + (tariff.slabs[i - 1] ? tariff.slabs[i - 1].upto : 0) + ' units';
      } else {
        units = Math.min(remaining, Math.max(slab.upto * scale - consumed, 0));
        label = (i === 0 ? 0 : tariff.slabs[i - 1].upto) + '\u2013' + slab.upto + ' units';
      }
      if (units <= 0) return;
      lines.push({ slab: label, units: Math.round(units * 100) / 100, rate: slab.rate,
                   amount: Math.round(units * slab.rate * 100) / 100 });
      consumed += units; remaining -= units;
    });
    var energy = lines.reduce(function (s, l) { return s + l.amount; }, 0);
    var fixed = (tariff.fixed_charge || 0) * scale;
    var duty = (energy + fixed) * (tariff.duty_percent || 0) / 100;
    var total = energy + fixed + duty;
    var co2 = kwh * DATA.settings.environment.co2_factor;
    return {
      kwh: kwh, days: days, lines: lines,
      energy_charge: Math.round(energy * 100) / 100,
      fixed_charge: Math.round(fixed * 100) / 100,
      duty: Math.round(duty * 100) / 100,
      duty_percent: tariff.duty_percent || 0,
      total: Math.round(total * 100) / 100,
      effective_rate: kwh ? Math.round(total / kwh * 100) / 100 : 0,
      co2_kg: Math.round(co2 * 10) / 10,
      currency_symbol: DATA.settings.tariff.currency_symbol,
      disclaimer: 'Estimate only, based on the tariff configured in Settings. It is not a ' +
                  'bill from your electricity provider.'
    };
  }

  function consumption(params) {
    var view = (params && params.view) || 'daily';
    var base = DATA.consumption[view];
    if (view !== 'daily') return ok(base);

    var full = base.detail.slice();                       // newest first
    var rows = full.filter(function (r) {
      if (params && params.start && r.date < params.start) return false;
      if (params && params.end && r.date > params.end) return false;
      return true;
    });
    if (!(params && (params.start || params.end))) rows = rows.slice(0, 30);
    if (!rows.length) rows = full.slice(0, 1);

    var chron = rows.slice().reverse();
    var complete = chron.filter(function (r) { return !r.partial; });
    var total = complete.reduce(function (s, r) { return s + r.kwh; }, 0);
    var days = complete.length || 1;
    var earlier = full.filter(function (r) { return r.date < chron[0].date; }).slice(0, days);
    var prevTotal = earlier.reduce(function (s, r) { return s + r.kwh; }, 0);
    var tariff = DATA.settings.tariff;

    return ok({
      view: 'daily',
      detail: rows,
      series: complete.map(function (r) {
        return { label: r.date, key: r.date, kwh: r.kwh, days: 1, peak_kwh: r.peak_kwh };
      }),
      typical_profile: base.typical_profile,
      hourly_today: base.hourly_today,
      previous_series: earlier.slice().reverse().map(function (r) {
        return { label: r.date, kwh: r.kwh };
      }),
      excluded_partial_days: chron.length - complete.length,
      currency_symbol: tariff.currency_symbol,
      summary: {
        total_kwh: Math.round(total * 10) / 10,
        days: days,
        avg_kwh: Math.round(total / days * 100) / 100,
        max_kwh: Math.max.apply(null, complete.map(function (r) { return r.kwh; })),
        min_kwh: Math.min.apply(null, complete.map(function (r) { return r.kwh; })),
        cost: estimateBill(total, days, tariff).total,
        previous_total_kwh: Math.round(prevTotal * 10) / 10,
        change_percent: prevTotal ? Math.round((total - prevTotal) / prevTotal * 1000) / 10 : null
      }
    });
  }

  global.API = {
    health: function () { return ok(DATA.health); },
    overview: function (range) { return ok(DATA.overview[range] || DATA.overview.month); },
    consumption: consumption,
    appliances: function () { return ok(DATA.appliances); },
    insights: function () { return ok(DATA.insights); },
    predictions: function () { return ok(DATA.predictions); },
    anomalies: function (params) {
      var key = 'normal';
      if (params && params.day_z >= 2.6) key = 'strict';
      else if (params && params.day_z <= 1.6) key = 'loose';
      return ok(DATA.anomalies[key]);
    },
    recommendations: function () { return ok(DATA.recommendations); },
    report: function (days) { return ok(DATA.report[String(days)] || DATA.report['30']); },
    settings: function () { return ok(DATA.settings); },
    estimateBill: function (body) {
      var tariff = Object.assign({}, DATA.settings.tariff, body.tariff || {});
      return ok(estimateBill(Number(body.kwh) || 0, Number(body.days) || 30, tariff));
    },
    saveSettings: function (body) {
      DATA.settings = Object.assign({}, DATA.settings, body);
      UI.toast('Saved for this browsing session. Run the project locally to keep changes.');
      return ok(DATA.settings);
    },
    resetSettings: function () {
      UI.toast('Resetting needs the local app.');
      return ok(DATA.settings);
    },
    regenerate: function () {
      UI.toast('Generating a new household needs the local app.');
      return ok({ status: 'demo', seed: DATA.settings.demo.seed,
                  hourly_readings: DATA.health.hourly_readings });
    },
    ask: function () {
      return ok({ enabled: false, answer: null,
                  message: 'Questions need the local app with an AI provider configured. ' +
                           'Every insight below was still generated without one.' });
    }
  };
})(window);
"""

BANNER = """
<div style="background:#10242e;color:#cfdcdc;padding:9px 16px;font:14px/1.5 'Inter','Segoe UI',
system-ui,sans-serif;text-align:center">
  Read-only preview of Smart Energy AI &mdash; a snapshot of the real interface.
  CSV download, saving settings and AI questions need the Python app running locally.
</div>
"""


def build():
    data = snapshot()
    css = read("css", "styles.css")
    html = read("index.html")

    body_start = html.index("<body>") + len("<body>")
    body_end = html.index("<script src=")
    shell = html[body_start:body_end]

    parts = [
        "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">",
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
        "<title>Smart Energy AI</title>",
        "<link rel=\"icon\" href=\"data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' "
        "viewBox='0 0 32 32'><text y='26' font-size='26'>&#9889;</text></svg>\">",
        "<style>\n" + css + "\n</style>\n</head>\n<body>",
        BANNER,
        shell,
        "<script>window.__SNAPSHOT__ = " + json.dumps(data, separators=(",", ":")) + ";</script>",
        "<script>\n" + read("js", "charts.js") + "\n</script>",
        "<script>\n" + SHIM + "\n</script>",
        "<script>\n" + read("js", "ui.js") + "\n</script>",
        "<script>\n" + read("js", "pages.js") + "\n</script>",
        "<script>\n" + read("js", "app.js") + "\n</script>",
        "</body>\n</html>\n",
    ]

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(parts))
    print("Wrote %s (%.0f KB)" % (OUT, os.path.getsize(OUT) / 1024))


if __name__ == "__main__":
    build()
